---
mode: agent
description: Generate a Bootstrap 5 + PHP look-alike template from measured capture data (capture/tokens.json + screenshots)
---

# Mission

Build a reusable, self-contained website template in `template/` that visually
matches the captured source site to **≥95% structural fidelity**, using ONLY
the measured data in `capture/tokens.json` and the screenshots in `capture/`
— while containing **zero content or code from the source site**.

# Inputs

1. `capture/tokens.json` — the single source of truth for every numeric and
   color value. Read it fully before writing any code.
2. `capture/home-{mobile,tablet,desktop}.png` and
   `capture/secondary-{mobile,tablet,desktop}.png` — use these ONLY to
   understand arrangement and visual character. If you cannot open image
   files from the workspace, ask the user to attach them to the chat.

# Hard rules (non-negotiable)

1. **Allowed stack, nothing else:** HTML5, CSS3, vanilla JavaScript, PHP,
   Bootstrap 5 (official CDN: CSS + `bootstrap.bundle.min.js`).
2. **Forbidden:** React, Vue, Angular, jQuery, Tailwind, TypeScript, Sass
   builds, npm packages, databases, Composer, any other framework/library.
3. **Originality — never copy from the source site:** no source CSS or JS
   (not even fragments), no source class names, no source text, no source
   images/logos/icons/fonts, no source asset URLs or hotlinks. Every line is
   authored fresh from the measured values in `tokens.json` plus your own
   observation of the screenshots. The single exception: nav-link labels
   from `tokens.navLinks` may be reused (short functional labels).
4. **No external requests** except the Bootstrap 5 CDN and Google Fonts.
5. **Runs with `php -S localhost:8000 -t template`** — no build step, no
   server config, no database.

# Output structure (exactly this)

```
template/
├─ index.php                  # home page
├─ <secondary>.php            # named after tokens.secondaryChoice (e.g. about.php)
├─ config.php                 # returns one array: brand, colors, fonts, nav, page content
├─ partials/
│  ├─ head.php                # <head>: meta, Bootstrap CDN, Google Fonts, theme.css
│  ├─ navbar.php
│  └─ footer.php
├─ components/                # one include per section pattern (hero.php, feature-grid.php, …)
└─ assets/
   ├─ css/theme.css           # all custom CSS (single file)
   ├─ js/main.js              # all custom JS (single file)
   └─ img/                    # generated SVG placeholders only
```

Pages are thin: they include partials/components and pass data arrays from
`config.php`. All dummy content lives in `config.php` so the template is
reusable by editing one file.

# Fidelity rules (exact values — this is where 95% is won)

- **Use measured values verbatim.** `tokens.summary` and each section entry
  contain exact px sizes, hex colors, paddings, radii, and shadows. Do NOT
  round them to Bootstrap defaults. Set them as CSS custom properties in
  `:root` inside `theme.css`, overriding Bootstrap's variables where they
  exist (`--bs-primary`, `--bs-body-font-family`, `--bs-body-color`,
  `--bs-border-radius`, button paddings, etc.) and adding custom properties
  where they don't.
- **Sections:** rebuild `tokens.pages.<page>.sections` in order. Match each
  section's role, height (±10%), effective background (exact hex or the
  recorded gradient), vertical padding, column count/widths/gap (map to the
  Bootstrap grid: `row` + `col-*` + `g-*`), heading size/weight/alignment,
  button count and style, and image count/aspect ratios.
- **Container:** if `tokens.summary.containerWidth` is set, size `.container`
  (or a custom container class) to match it at the desktop breakpoint.
- **Buttons & hover:** implement `tokens.summary.buttons` variants exactly
  (bg, color, radius, padding, weight, transform) and apply
  `tokens.hoverStates` deltas as `:hover` rules with the recorded transition
  durations/easings.
- **Responsive:** must match the arrangement in all three screenshots. Use
  Bootstrap breakpoints, adjusted with custom media queries if
  `tokens.breakpointsPx` differs meaningfully.
- **Fonts:** check `tokens.meta.fontMode`.
  - `open-sans` → use "Open Sans" (Google Fonts) for everything.
  - `auto` → for each captured family in `tokens.summary.fonts`, pick the
    closest OFL-licensed Google Font (serif→serif, geometric→geometric,
    display→display) and state your mapping in a comment in `head.php`.
  Either way, keep the measured sizes, weights, line-heights, and
  letter-spacing — only the family substitutes.

# Content rules

- All copy is **original dummy text** (lorem-style or neutral generic copy).
  Match lengths to the measured stats: headings within ±15% of recorded
  word counts, paragraph blocks within ±15% of recorded character totals,
  so spacing and line wrapping behave like the original.
- Brand: use a neutral placeholder name (e.g. "Acme Studio") — never the
  source brand.
- Nav: reuse `tokens.navLinks` labels; home + secondary link to the two
  generated pages, all other links `href="#"`.
- Forms (if the original has them): correct fields per the screenshot,
  `method="post"` to the same page, with a tiny PHP stub that prints a
  success alert — no mail(), no storage.

# Placeholder rules

- Every image slot gets a **generated SVG file** in `assets/img/` at the
  recorded aspect ratio: `#e9ecef` background, `#adb5bd` centered label
  with the dimensions (e.g. `IMAGE 800×600`). Logo slots: bordered box with
  the text `LOGO`. Descriptive `alt` text on all of them.
- Background-image sections: SVG placeholder or the recorded gradient as
  the CSS background; add an overlay if the screenshot shows one.

# Motion rules

- Recreate `tokens.pages.<page>.animations` in `theme.css` as `@keyframes`
  using the recorded durations, delays, easings, and numeric keyframe
  values (transform/opacity). Scroll-reveals: implement with an
  IntersectionObserver in `main.js` that toggles an `.is-visible` class.
- Recreate `tokens.pages.<page>.transitions` as CSS `transition` rules on
  the matching element types.
- Wrap all motion in `@media (prefers-reduced-motion: no-preference)`.
- Anything that cannot be rebuilt in this stack (canvas, WebGL, video
  backgrounds, complex JS timelines): substitute a static gradient or
  placeholder, and mark the section wrapper with
  `data-fallback="short description"` plus an HTML comment — validate.js
  reports these for manual review.

# Workflow

1. Read `capture/tokens.json` end to end; study all screenshots.
2. Scaffold the folder structure and `config.php`.
3. Build `partials/head.php`, `navbar.php`, `footer.php` from the navbar and
   footer section data.
4. Build home sections in order, one component per section pattern; then the
   secondary page reusing components.
5. Write `theme.css`: `:root` tokens first, then per-component rules, then
   keyframes/media queries. Keep selector specificity flat to avoid rules
   canceling each other (watch section padding overrides).
6. Write `main.js`: navbar behavior if needed, IntersectionObserver reveals,
   any Bootstrap component init.
7. Self-review against all six screenshots at 375/768/1440 before finishing.
8. Tell the user to run `npm run validate`, and list any `data-fallback`
   sections you created.

# Definition of done

- [ ] Both pages render via `php -S` with no PHP warnings
- [ ] Only allowed technologies; Bootstrap CDN + Google Fonts are the only
      external requests
- [ ] Zero source-site text, code, class names, assets, or URLs anywhere
- [ ] Every section present, in order, with exact measured colors/sizes
- [ ] Responsive arrangement matches all three viewport screenshots
- [ ] Hover states and animations implemented from tokens; reduced motion
      respected
- [ ] All images are local SVG placeholders with alt text
- [ ] Fallback sections (if any) are marked with `data-fallback`
