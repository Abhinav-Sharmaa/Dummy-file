#!/usr/bin/env node
'use strict';

/*
 * capture.js — Stage 1 of the template pipeline.
 *
 * Renders a target URL (plus one secondary page) in headless Chromium and
 * writes MEASURED design data into ./capture:
 *   - full-page screenshots at 375 / 768 / 1440
 *   - tokens.json: palette, typography, spacing, radii, shadows, buttons,
 *     breakpoints, section geometry, image dimensions/ratios, animation
 *     timing + numeric keyframes, hover-state deltas, text LENGTH stats.
 *
 * Data policy: measured values only. This script never stores source text
 * (nav labels excepted), source CSS/JS, images, or asset URLs.
 *
 * Usage:
 *   node capture.js <url> [secondaryPathOrUrl] [--font=open-sans|auto] [--out=capture]
 * Examples:
 *   node capture.js https://example.com
 *   node capture.js https://example.com /about --font=auto
 */

const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const { extractPageData, collectNavLinks, VIEWPORTS } = require('./lib/extract');

const SECONDARY_PRIORITY = [
  { re: /about/i, label: 'about' },
  { re: /service/i, label: 'services' },
  { re: /contact/i, label: 'contact' },
  { re: /team|people/i, label: 'team' },
  { re: /work|portfolio|project/i, label: 'work' },
  { re: /pricing|plans/i, label: 'pricing' },
];

function usage() {
  console.log('Usage: node capture.js <url> [secondaryPathOrUrl] [--font=open-sans|auto] [--out=capture]');
}

function parseArgs(argv) {
  const args = { font: 'open-sans', out: 'capture', url: null, secondary: null };
  const positional = [];
  for (const a of argv) {
    if (a.startsWith('--font=')) args.font = a.split('=')[1];
    else if (a.startsWith('--out=')) args.out = a.split('=')[1];
    else if (a === '--help' || a === '-h') { usage(); process.exit(0); }
    else positional.push(a);
  }
  args.url = positional[0] || null;
  args.secondary = positional[1] || null;
  return args;
}

async function settle(page) {
  try { await page.waitForLoadState('networkidle', { timeout: 12000 }); } catch (_) { /* SPAs may never idle */ }
  await page.waitForTimeout(600);
}

// Scroll through the page to trigger lazy-loading and scroll animations,
// then return to the top.
async function autoScroll(page) {
  await page.evaluate(async () => {
    const step = Math.max(200, Math.floor(window.innerHeight * 0.7));
    let y = 0;
    for (let i = 0; i < 60; i++) {
      y += step;
      window.scrollTo(0, y);
      await new Promise((r) => setTimeout(r, 120));
      if (y >= document.documentElement.scrollHeight) break;
    }
    window.scrollTo(0, 0);
    await new Promise((r) => setTimeout(r, 450));
  });
}

function resolveSecondary(navLinks, override, baseUrl) {
  const base = new URL(baseUrl);
  if (override) {
    const u = new URL(override, base.origin);
    return { url: u.toString(), path: u.pathname, reason: 'user-specified' };
  }
  const homePath = base.pathname.replace(/\/+$/, '') || '/';
  const candidates = (navLinks || []).filter((l) => {
    const p = (l.path || '').split('?')[0].replace(/\/+$/, '') || '/';
    return p !== homePath;
  });
  for (const pri of SECONDARY_PRIORITY) {
    const hit = candidates.find((l) => pri.re.test(l.text) || pri.re.test(l.path));
    if (hit) {
      return {
        url: new URL(hit.path, base.origin).toString(),
        path: hit.path,
        label: hit.text,
        reason: 'matched priority: ' + pri.label,
      };
    }
  }
  if (candidates[0]) {
    return {
      url: new URL(candidates[0].path, base.origin).toString(),
      path: candidates[0].path,
      label: candidates[0].text,
      reason: 'first internal nav link',
    };
  }
  return null;
}

// Hover a sample of interactive elements and record computed-style deltas
// (measured values). Runs at the desktop viewport.
async function captureHoverStates(page) {
  const out = [];
  const seen = new Set();
  let handles = [];
  try { handles = await page.$$('a[href], button, input[type="submit"], [role="button"]'); } catch (_) { return out; }
  for (const h of handles) {
    if (out.length >= 10) break;
    try {
      const info = await h.evaluate((el) => {
        const r = el.getBoundingClientRect();
        if (r.width < 24 || r.height < 12) return null;
        const c = getComputedStyle(el);
        if (c.visibility === 'hidden' || c.display === 'none') return null;
        return {
          tag: el.tagName.toLowerCase(),
          sig: [el.tagName, c.fontSize, c.backgroundColor, c.color, c.borderRadius].join('|'),
          base: {
            backgroundColor: c.backgroundColor, color: c.color,
            borderColor: c.borderTopColor, boxShadow: c.boxShadow,
            transform: c.transform, opacity: c.opacity,
            textDecorationLine: c.textDecorationLine,
          },
        };
      });
      if (!info || seen.has(info.sig)) continue;
      seen.add(info.sig);
      await h.scrollIntoViewIfNeeded({ timeout: 1500 });
      await h.hover({ timeout: 1500 });
      await page.waitForTimeout(280);
      const hovered = await h.evaluate((el) => {
        const c = getComputedStyle(el);
        return {
          backgroundColor: c.backgroundColor, color: c.color,
          borderColor: c.borderTopColor, boxShadow: c.boxShadow,
          transform: c.transform, opacity: c.opacity,
          textDecorationLine: c.textDecorationLine,
        };
      });
      const changes = {};
      for (const k of Object.keys(hovered)) {
        if (hovered[k] !== info.base[k]) changes[k] = { from: info.base[k], to: hovered[k] };
      }
      if (Object.keys(changes).length) out.push({ target: info.tag, changes });
    } catch (_) { /* skip flaky elements */ }
  }
  try { await page.mouse.move(2, 2); } catch (_) { /* ignore */ }
  return out;
}

(async () => {
  const args = parseArgs(process.argv.slice(2));
  if (!args.url) { usage(); process.exit(2); }
  if (!['open-sans', 'auto'].includes(args.font)) {
    console.error('Invalid --font value. Use open-sans or auto.');
    process.exit(2);
  }
  let baseUrl;
  try { baseUrl = new URL(args.url).toString(); } catch (_) {
    console.error('Invalid URL:', args.url);
    process.exit(2);
  }

  const outDir = path.resolve(args.out);
  fs.mkdirSync(outDir, { recursive: true });

  const tokens = {
    meta: {
      sourceUrl: baseUrl,
      capturedAt: new Date().toISOString(),
      fontMode: args.font, // open-sans (default) | auto (closest free Google Font)
      tool: 'capture.js v1',
      viewports: VIEWPORTS,
      note: 'Measured values and text-length stats only. No source text, code, images, or asset URLs are stored.',
    },
    breakpointsPx: [],
    summary: null,
    hoverStates: [],
    pages: {},
    navLinks: [],
    secondaryChoice: null,
  };

  const browser = await chromium.launch();
  try {
    const context = await browser.newContext({ deviceScaleFactor: 1 });
    const page = await context.newPage();
    page.setDefaultTimeout(45000);

    console.log('Loading', baseUrl);
    await page.setViewportSize({ width: VIEWPORTS[2].width, height: VIEWPORTS[2].height });
    await page.goto(baseUrl, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await settle(page);

    const navLinks = await page.evaluate(collectNavLinks);
    const secondary = resolveSecondary(navLinks, args.secondary, baseUrl);
    tokens.navLinks = navLinks;
    tokens.secondaryChoice = secondary;

    const pageDefs = [{ key: 'home', url: baseUrl }];
    if (secondary) {
      pageDefs.push({ key: 'secondary', url: secondary.url });
      console.log('Secondary page:', secondary.path, '(' + secondary.reason + ')');
    } else {
      console.warn('No internal secondary page found — capturing home only.');
    }

    for (const def of pageDefs) {
      console.log('\nCapturing', def.key, '→', def.url);
      tokens.pages[def.key] = { url: def.url, docHeights: {} };
      for (const vp of VIEWPORTS) {
        await page.setViewportSize({ width: vp.width, height: vp.height });
        await page.goto(def.url, { waitUntil: 'domcontentloaded' });
        await settle(page);
        await autoScroll(page);
        const shot = path.join(outDir, `${def.key}-${vp.name}.png`);
        await page.screenshot({ path: shot, fullPage: true, animations: 'disabled' });
        tokens.pages[def.key].docHeights[vp.name] =
          await page.evaluate(() => Math.round(document.documentElement.scrollHeight));
        console.log('  •', path.basename(shot));

        if (vp.name === 'desktop') {
          const data = await page.evaluate(extractPageData, { maxElements: 4000 });
          Object.assign(tokens.pages[def.key], {
            sections: data.sections,
            images: data.images,
            animations: data.animations,
            transitions: data.transitions,
            textStats: data.textStats,
          });
          if (def.key === 'home') {
            tokens.summary = {
              palette: data.palette,
              fonts: data.fonts,
              typography: data.typography,
              spacingScale: data.spacingScale,
              radii: data.radii,
              shadows: data.shadows,
              buttons: data.buttons,
              containerWidth: data.containerWidth,
            };
            tokens.breakpointsPx = data.breakpointsPx;
            console.log('  • extracting hover states…');
            tokens.hoverStates = await captureHoverStates(page);
          }
        }
      }
    }

    const tokensPath = path.join(outDir, 'tokens.json');
    fs.writeFileSync(tokensPath, JSON.stringify(tokens, null, 2));

    const home = tokens.pages.home || {};
    console.log('\n──────── capture summary ────────');
    console.log('Sections (home):     ', (home.sections || []).length);
    console.log('Colors captured:     ',
      ((tokens.summary || {}).palette || { text: [], background: [] }).text.length +
      ((tokens.summary || {}).palette || { text: [], background: [] }).background.length);
    console.log('Font families seen:  ',
      ((tokens.summary || {}).fonts || []).map((f) => f.value).join(', ') || '—');
    console.log('Animations captured: ', (home.animations || []).length,
      '| transitions:', (home.transitions || []).length,
      '| hover states:', tokens.hoverStates.length);
    console.log('Breakpoints (px):    ', tokens.breakpointsPx.join(', ') || '—');
    console.log('Output:              ', outDir);
    console.log('\nNext: open VS Code → Copilot Chat (Agent mode) → run /generate-template');
    console.log('      and attach the PNGs in', path.basename(outDir) + '/');
  } catch (err) {
    console.error('\nCapture failed:', err.message);
    process.exitCode = 1;
  } finally {
    await browser.close();
  }
})();
