#!/usr/bin/env node
'use strict';

/*
 * validate.js — Stage 4 of the template pipeline.
 *
 * Serves ./template with PHP's built-in server, re-captures it at the same
 * three viewports, and compares it against ./capture:
 *   - section-level: height, background color, column count, heading size
 *   - image-level:  downscaled grayscale "layout similarity" per viewport
 *     (raw pixel diffing is meaningless once text/images are replaced)
 *
 * Outputs ./validation/report.html (side-by-side) and report.json (the
 * itemized deltas you paste back into the Copilot agent chat).
 *
 * Usage:
 *   node validate.js [--template=template] [--capture=capture] [--out=validation]
 *                    [--port=8090] [--threshold=95] [--secondary-file=about.php]
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const { spawn } = require('child_process');
const { chromium } = require('playwright');
const { PNG } = require('pngjs');
const { extractPageData, VIEWPORTS } = require('./lib/extract');

function parseArgs(argv) {
  const args = {
    template: 'template', capture: 'capture', out: 'validation',
    port: 8090, threshold: 95, secondaryFile: null,
  };
  for (const a of argv) {
    if (a.startsWith('--template=')) args.template = a.split('=')[1];
    else if (a.startsWith('--capture=')) args.capture = a.split('=')[1];
    else if (a.startsWith('--out=')) args.out = a.split('=')[1];
    else if (a.startsWith('--port=')) args.port = parseInt(a.split('=')[1], 10);
    else if (a.startsWith('--threshold=')) args.threshold = parseFloat(a.split('=')[1]);
    else if (a.startsWith('--secondary-file=')) args.secondaryFile = a.split('=')[1];
  }
  return args;
}

async function settle(page) {
  try { await page.waitForLoadState('networkidle', { timeout: 8000 }); } catch (_) { /* ok */ }
  await page.waitForTimeout(400);
}

async function autoScroll(page) {
  await page.evaluate(async () => {
    const step = Math.max(200, Math.floor(window.innerHeight * 0.7));
    let y = 0;
    for (let i = 0; i < 60; i++) {
      y += step;
      window.scrollTo(0, y);
      await new Promise((r) => setTimeout(r, 90));
      if (y >= document.documentElement.scrollHeight) break;
    }
    window.scrollTo(0, 0);
    await new Promise((r) => setTimeout(r, 350));
  });
}

function waitForServer(url, timeoutMs) {
  return new Promise((resolve, reject) => {
    const t0 = Date.now();
    (function ping() {
      const req = http.get(url, (res) => { res.resume(); resolve(); });
      req.on('error', () => {
        if (Date.now() - t0 > timeoutMs) reject(new Error('PHP server did not start on ' + url));
        else setTimeout(ping, 300);
      });
    })();
  });
}

function findSecondaryFile(templateDir, capturedPath, explicit) {
  if (explicit) return explicit;
  let files = [];
  try {
    files = fs.readdirSync(templateDir).filter((f) =>
      f.endsWith('.php') &&
      !['index.php', 'config.php'].includes(f) &&
      fs.statSync(path.join(templateDir, f)).isFile());
  } catch (_) { return null; }
  if (!files.length) return null;
  if (capturedPath) {
    const base = capturedPath.replace(/\/+$/, '').split('/').pop()
      .toLowerCase().replace(/\.(php|html?)$/, '');
    if (base) {
      const stem = (f) => f.toLowerCase().replace(/\.php$/, '');
      const hit = files.find((f) => base.includes(stem(f)) || stem(f).includes(base));
      if (hit) return hit;
    }
  }
  return files.sort()[0];
}

// ---------- scoring ----------
const r1 = (n) => Math.round(n * 10) / 10;

function hexToRgb(h) {
  if (!h || !/^#[0-9a-f]{6}$/i.test(h)) return null;
  return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
}
function colorSim(a, b) {
  const A = hexToRgb(a), B = hexToRgb(b);
  if (!A || !B) return 0.7; // unknown → neutral
  const d = Math.sqrt((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2 + (A[2] - B[2]) ** 2);
  return 1 - d / 441.67;
}

function compareSections(orig, gen) {
  orig = orig || []; gen = gen || [];
  const pairs = Math.min(orig.length, gen.length);
  const most = Math.max(orig.length, gen.length, 1);
  const rows = [];
  let total = 0;
  for (let i = 0; i < pairs; i++) {
    const o = orig[i], g = gen[i];
    const hSim = 1 - Math.min(1, Math.abs(o.height - g.height) / Math.max(o.height, g.height, 1));
    const bgSim = Math.max(0, colorSim(o.background, g.background));
    const oCols = (o.columns && o.columns.count) || 1;
    const gCols = (g.columns && g.columns.count) || 1;
    const cSim = oCols === gCols ? 1 : 0.4;
    const oHead = o.heading && o.heading.px, gHead = g.heading && g.heading.px;
    const headSim = (oHead && gHead)
      ? 1 - Math.min(1, Math.abs(oHead - gHead) / Math.max(oHead, gHead))
      : (oHead || gHead ? 0.6 : 1);
    const score = (hSim * 0.35 + bgSim * 0.25 + cSim * 0.25 + headSim * 0.15) * 100;
    total += score;

    const deltas = [];
    if (hSim < 0.9) deltas.push(`height ${o.height}px → ${g.height}px`);
    if (bgSim < 0.92) deltas.push(`background ${o.background} → ${g.background}`);
    if (cSim < 1) deltas.push(`columns ${oCols} → ${gCols}`);
    if (headSim < 0.9) deltas.push(`max heading ${oHead || '—'}px → ${gHead || '—'}px`);
    rows.push({ index: i, role: o.role, score: r1(score), deltas });
  }
  if (gen.length !== orig.length) {
    rows.push({
      index: pairs, role: 'structure', score: 0,
      deltas: [`section count ${orig.length} → ${gen.length}`],
    });
  }
  const score = pairs ? (total / pairs) * (pairs / most) : 0;
  return { score: r1(score), rows, counts: { original: orig.length, generated: gen.length } };
}

// Downscale to a coarse grayscale grid and compare — a layout-shape
// similarity heuristic that ignores exact text/photo pixels.
function loadGrayGrid(file, gridW) {
  const png = PNG.sync.read(fs.readFileSync(file));
  const scale = png.width / gridW;
  const gridH = Math.max(1, Math.round(png.height / scale));
  const sum = new Float64Array(gridW * gridH);
  const cnt = new Float64Array(gridW * gridH);
  for (let y = 0; y < png.height; y++) {
    const gy = Math.min(gridH - 1, Math.floor(y / scale));
    for (let x = 0; x < png.width; x++) {
      const gx = Math.min(gridW - 1, Math.floor(x / scale));
      const i = (png.width * y + x) << 2;
      const lum = 0.299 * png.data[i] + 0.587 * png.data[i + 1] + 0.114 * png.data[i + 2];
      const gi = gy * gridW + gx;
      sum[gi] += lum; cnt[gi]++;
    }
  }
  for (let i = 0; i < sum.length; i++) sum[i] /= cnt[i] || 1;
  return { grid: sum, w: gridW, h: gridH };
}

function layoutSimilarity(fileA, fileB) {
  const W = 48;
  const A = loadGrayGrid(fileA, W);
  const B = loadGrayGrid(fileB, W);
  const h = Math.min(A.h, B.h);
  if (!h) return 0;
  let sum = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < W; x++) sum += Math.abs(A.grid[y * W + x] - B.grid[y * W + x]);
  }
  const sim = 1 - sum / (h * W) / 255;
  const hRatio = Math.min(A.h, B.h) / Math.max(A.h, B.h);
  return r1(sim * (0.6 + 0.4 * hRatio) * 100);
}

// ---------- report ----------
function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function chip(score, threshold) {
  const cls = score >= threshold ? 'good' : score >= threshold - 10 ? 'warn' : 'bad';
  return `<span class="chip ${cls}">${score}</span>`;
}
function buildReportHtml(report, relCapture) {
  const t = report.threshold;
  let body = '';
  for (const [key, pg] of Object.entries(report.pages)) {
    body += `<h2>${esc(key)} <small>overall ${chip(pg.overall, t)}</small></h2>`;
    body += '<div class="pairs">';
    for (const vp of VIEWPORTS) {
      const score = pg.imageScores[vp.name];
      body += `
      <figure>
        <figcaption>${vp.name} · layout similarity ${chip(score != null ? score : 0, t)}</figcaption>
        <div class="pair">
          <div><span class="tag">original</span><img loading="lazy" src="${relCapture}/${key}-${vp.name}.png" alt="original ${esc(key)} ${vp.name}"></div>
          <div><span class="tag">generated</span><img loading="lazy" src="${key}-${vp.name}.png" alt="generated ${esc(key)} ${vp.name}"></div>
        </div>
      </figure>`;
    }
    body += '</div>';
    body += `<table><thead><tr><th>#</th><th>role</th><th>score</th><th>deltas (paste these into the Copilot agent chat)</th></tr></thead><tbody>`;
    for (const row of pg.sections.rows) {
      body += `<tr><td>${row.index}</td><td>${esc(row.role || '')}</td><td>${chip(row.score, t)}</td><td>${esc(row.deltas.join('; ') || '—')}</td></tr>`;
    }
    body += '</tbody></table>';
    if (pg.fallbacks && pg.fallbacks.length) {
      body += `<p class="fallbacks">Fallback sections (agent simplified these — review manually): ${
        pg.fallbacks.map((f) => esc(f.tag + (f.note ? ' — ' + f.note : ''))).join(' · ')}</p>`;
    }
  }
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Template fidelity report</title>
<style>
  :root { color-scheme: light; }
  body { font: 15px/1.55 ui-sans-serif, system-ui, sans-serif; color: #1c1c1c; margin: 2rem auto; max-width: 1200px; padding: 0 1rem; }
  h1 { font-size: 1.5rem; letter-spacing: -0.01em; }
  h2 { margin-top: 2.5rem; border-top: 1px solid #ddd; padding-top: 1rem; }
  .chip { display: inline-block; min-width: 3.2em; text-align: center; padding: 0.05em 0.45em; border-radius: 999px; font-variant-numeric: tabular-nums; font-weight: 600; }
  .chip.good { background: #dcefdd; color: #185c1e; }
  .chip.warn { background: #fbeccd; color: #7a5200; }
  .chip.bad  { background: #f8d7d7; color: #8a1f1f; }
  .pair { display: flex; gap: 8px; }
  .pair > div { flex: 1; min-width: 0; }
  .pair img { width: 100%; border: 1px solid #ddd; border-radius: 4px; display: block; }
  .tag { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.06em; color: #666; }
  figure { margin: 1rem 0; }
  figcaption { margin-bottom: 0.35rem; font-weight: 600; }
  table { border-collapse: collapse; width: 100%; margin-top: 0.5rem; }
  th, td { text-align: left; padding: 0.4rem 0.6rem; border-bottom: 1px solid #eee; vertical-align: top; }
  th { font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.05em; color: #666; }
  .fallbacks { background: #fff8e6; border: 1px solid #f0e0b0; padding: 0.6rem 0.8rem; border-radius: 6px; }
  .meta { color: #666; }
</style></head><body>
<h1>Template fidelity report ${chip(report.overall, t)} <small class="meta">threshold ${t}</small></h1>
<p class="meta">Generated ${esc(report.generatedAt)} · section geometry 60% + layout similarity 40%. Scores are heuristics — always eyeball the pairs.</p>
${body}
</body></html>`;
}

// ---------- main ----------
(async () => {
  const args = parseArgs(process.argv.slice(2));
  const templateDir = path.resolve(args.template);
  const captureDir = path.resolve(args.capture);
  const outDir = path.resolve(args.out);

  const tokensPath = path.join(captureDir, 'tokens.json');
  if (!fs.existsSync(tokensPath)) {
    console.error('Missing', tokensPath, '— run `npm run capture -- <url>` first.');
    process.exit(2);
  }
  if (!fs.existsSync(path.join(templateDir, 'index.php'))) {
    console.error('Missing', path.join(templateDir, 'index.php'),
      '— generate the template with the Copilot agent first.');
    process.exit(2);
  }
  fs.mkdirSync(outDir, { recursive: true });
  const tokens = JSON.parse(fs.readFileSync(tokensPath, 'utf8'));

  const pageDefs = [{ key: 'home', file: 'index.php' }];
  if (tokens.pages && tokens.pages.secondary) {
    const secFile = findSecondaryFile(
      templateDir,
      tokens.secondaryChoice && tokens.secondaryChoice.path,
      args.secondaryFile
    );
    if (secFile) pageDefs.push({ key: 'secondary', file: secFile });
    else console.warn('No secondary .php found in template/ — validating home only.');
  }

  const host = '127.0.0.1';
  const baseUrl = `http://${host}:${args.port}`;
  const php = spawn('php', ['-S', `${host}:${args.port}`, '-t', templateDir], { stdio: 'ignore' });
  let phpFailed = false;
  php.on('error', () => { phpFailed = true; });

  let browser = null;
  const report = {
    generatedAt: new Date().toISOString(),
    threshold: args.threshold,
    pages: {},
    overall: 0,
  };

  try {
    await waitForServer(baseUrl + '/index.php', 8000);
    if (phpFailed) throw new Error('php binary not found');

    browser = await chromium.launch();
    const context = await browser.newContext({ deviceScaleFactor: 1 });
    const page = await context.newPage();
    page.setDefaultTimeout(30000);

    for (const def of pageDefs) {
      const url = `${baseUrl}/${def.file}`;
      console.log('Validating', def.key, '→', url);
      const imageScores = {};
      let genSections = [];
      let fallbacks = [];

      for (const vp of VIEWPORTS) {
        await page.setViewportSize({ width: vp.width, height: vp.height });
        await page.goto(url, { waitUntil: 'domcontentloaded' });
        await settle(page);
        await autoScroll(page);
        const shot = path.join(outDir, `${def.key}-${vp.name}.png`);
        await page.screenshot({ path: shot, fullPage: true, animations: 'disabled' });

        const origShot = path.join(captureDir, `${def.key}-${vp.name}.png`);
        if (fs.existsSync(origShot)) {
          try { imageScores[vp.name] = layoutSimilarity(origShot, shot); }
          catch (e) { console.warn('  image diff failed for', vp.name + ':', e.message); }
        }

        if (vp.name === 'desktop') {
          const data = await page.evaluate(extractPageData, { maxElements: 4000 });
          genSections = data.sections;
          fallbacks = await page.$$eval('[data-fallback]', (els) =>
            els.map((e) => ({ tag: e.tagName.toLowerCase(), note: e.getAttribute('data-fallback') || '' })));
        }
      }

      const origSections = (tokens.pages[def.key] || {}).sections || [];
      const sections = compareSections(origSections, genSections);
      const imgVals = Object.values(imageScores);
      const imgAvg = imgVals.length ? imgVals.reduce((a, b) => a + b, 0) / imgVals.length : 0;
      const overall = r1(sections.score * 0.6 + imgAvg * 0.4);
      report.pages[def.key] = { overall, sectionScore: sections.score, imageScores, sections, fallbacks };
    }

    const pageVals = Object.values(report.pages).map((p) => p.overall);
    report.overall = r1(pageVals.reduce((a, b) => a + b, 0) / Math.max(1, pageVals.length));

    fs.writeFileSync(path.join(outDir, 'report.json'), JSON.stringify(report, null, 2));
    const rel = path.relative(outDir, captureDir).split(path.sep).join('/') || '.';
    fs.writeFileSync(path.join(outDir, 'report.html'), buildReportHtml(report, rel));

    // console summary
    console.log('\n──────── fidelity report ────────');
    for (const [key, pg] of Object.entries(report.pages)) {
      const imgs = VIEWPORTS.map((v) => `${v.name} ${pg.imageScores[v.name] != null ? pg.imageScores[v.name] : '—'}`).join(' · ');
      console.log(`${key.padEnd(10)} sections ${pg.sectionScore}  |  ${imgs}  →  ${pg.overall}`);
      const weak = pg.sections.rows.filter((r) => r.score < args.threshold && r.deltas.length);
      for (const w of weak) console.log(`   · section ${w.index} (${w.role || '—'}) ${w.score}: ${w.deltas.join('; ')}`);
      if (pg.fallbacks.length) console.log(`   · ${pg.fallbacks.length} fallback section(s) need manual review`);
    }
    const pass = report.overall >= args.threshold;
    console.log(`\nOVERALL ${report.overall} / threshold ${args.threshold} — ${pass ? 'PASS ✅' : 'BELOW ❌'}`);
    console.log('Report:', path.join(outDir, 'report.html'));
    if (!pass) console.log('Loop: paste the section deltas above (or from report.json) into the Copilot agent chat, then re-run validate.');
    process.exitCode = pass ? 0 : 1;
  } catch (err) {
    if (phpFailed || /php/i.test(err.message)) {
      console.error('\nCould not start PHP. Install PHP CLI (php -v) and ensure it is on your PATH.');
    } else {
      console.error('\nValidation failed:', err.message);
    }
    process.exitCode = 2;
  } finally {
    if (browser) await browser.close();
    try { php.kill('SIGTERM'); } catch (_) { /* already dead */ }
  }
})();
