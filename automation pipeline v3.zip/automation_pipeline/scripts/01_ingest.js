// 01_ingest.js — Read Fiserv export, append new tickets to tracker
//
// Usage: node scripts/01_ingest.js [path-to-fiserv-export.xlsx]
//
// Reads the Excel you exported from Fiserv (with columns: Client Name,
// Inquiry Number, Short Description, Inquiry Details, Assigned To) and
// appends NEW rows to your tracker (dedupes by Inquiry Number).
// Adds these automation columns: Status, Category, Effort, AI Summary,
// Received Date, UAT Doc Path, Last Updated.

const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');
const config = require('../config.json');

const FISERV_COLUMNS = ['Client Name', 'Inquiry Number', 'Short Description', 'Inquiry Details', 'Assigned To'];
const TRACKER_COLUMNS = [
  ...FISERV_COLUMNS,
  'Status', 'Category', 'Effort', 'AI Summary',
  'Received Date', 'UAT Doc Path', 'Last Updated'
];

function readSheet(filePath) {
  if (!fs.existsSync(filePath)) return [];
  const wb = XLSX.readFile(filePath);
  const ws = wb.Sheets[wb.SheetNames[0]];
  return XLSX.utils.sheet_to_json(ws, { defval: '' });
}

function writeSheet(filePath, rows) {
  const ws = XLSX.utils.json_to_sheet(rows, { header: TRACKER_COLUMNS });
  // Set column widths for readability
  ws['!cols'] = TRACKER_COLUMNS.map(c => ({ wch: Math.min(Math.max(c.length, 15), 40) }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Tickets');
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  XLSX.writeFile(wb, filePath);
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function main() {
  const exportPath = process.argv[2] || config.paths.fiserv_export;
  const trackerPath = config.paths.tracker;

  console.log(`📥 Reading Fiserv export:  ${exportPath}`);
  const incoming = readSheet(exportPath);
  if (incoming.length === 0) {
    console.error(`❌ No rows found in ${exportPath}`);
    process.exit(1);
  }

  console.log(`📋 Reading existing tracker: ${trackerPath}`);
  const existing = readSheet(trackerPath);
  const existingIds = new Set(existing.map(r => String(r['Inquiry Number']).trim()));

  // Validate columns
  const sample = incoming[0];
  const missing = FISERV_COLUMNS.filter(c => !(c in sample));
  if (missing.length) {
    console.error(`❌ Export is missing columns: ${missing.join(', ')}`);
    console.error(`   Found columns: ${Object.keys(sample).join(', ')}`);
    process.exit(1);
  }

  // Dedupe and add automation columns
  const newRows = [];
  for (const row of incoming) {
    const id = String(row['Inquiry Number']).trim();
    if (!id || existingIds.has(id)) continue;

    newRows.push({
      'Client Name':       row['Client Name'],
      'Inquiry Number':    id,
      'Short Description': row['Short Description'],
      'Inquiry Details':   row['Inquiry Details'],
      'Assigned To':       row['Assigned To'],
      'Status':            'New',
      'Category':          '',          // filled by 02_classify.js
      'Effort':            '',          // filled by 02_classify.js
      'AI Summary':        '',          // filled by 02_classify.js
      'Received Date':     todayISO(),
      'UAT Doc Path':      '',          // filled by 04_generate_uat.js
      'Last Updated':      todayISO()
    });
  }

  if (newRows.length === 0) {
    console.log(`✅ No new tickets. Tracker has ${existing.length} rows.`);
    return;
  }

  const combined = [...existing, ...newRows];
  writeSheet(trackerPath, combined);

  console.log(`✅ Added ${newRows.length} new ticket(s). Tracker now has ${combined.length} rows.`);
  console.log(`   → ${trackerPath}`);
  console.log(`\nNew tickets:`);
  newRows.forEach(r => console.log(`   • ${r['Inquiry Number']}  ${r['Client Name']}  —  ${String(r['Short Description']).slice(0, 60)}`));
}

main();
