// build_sample.js — create a sample Fiserv-style export for testing
const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');

const rows = [
  { 'Client Name': 'COMMUNITY FIN',     'Inquiry Number': 'IP30197749', 'Short Description': 'CUSCD-WH-COMMUNITY FIN-Banner update',                'Inquiry Details': 'On our home page the holiday banner needs to be updated. Please change the text from "Memorial Day Hours" to "Summer Hours: Open Mon-Fri 8am-5pm" and update the background image to the summer one we sent last week.', 'Assigned To': 'Shama Begam' },
  { 'Client Name': 'COMMUNITY FIN',     'Inquiry Number': 'IP30194877', 'Short Description': 'CUSCD-WH-COMMUNITY FIN-Marketing campaign',          'Inquiry Details': 'We are doing a marketing campaign for our new auto loan rates. Please add a promotional tile on the home page below the hero banner with text "Auto Loans as low as 4.99% APR" linking to /loans/auto.', 'Assigned To': 'Shama Begam' },
  { 'Client Name': 'COMMUNITY FIN',     'Inquiry Number': 'IP30081002', 'Short Description': 'CUSCD-WH-COMMUNITY FIN-Logo update',                  'Inquiry Details': 'We have a new Logo and want to replace the existing one across the entire site including the header, footer, and favicon. New logo files are attached in the ticket.', 'Assigned To': 'Shama Begam' },
  { 'Client Name': 'FIRE FIGHTERS C',   'Inquiry Number': 'IP30186951', 'Short Description': 'CUSCD-WH-FIRE FIGHTERS-Remove section',               'Inquiry Details': 'Could you please stop displaying the COVID-19 announcement section at the top of every page. It is no longer relevant.', 'Assigned To': 'Abhinav Sharma' },
  { 'Client Name': 'ONTARIO PUBLIC',    'Inquiry Number': 'IP29975841', 'Short Description': 'Chairperson photo update',                            'Inquiry Details': 'Our chairperson would like to update her photo on the About Us page. New headshot is attached. Please also update her title from "Interim Chairperson" to "Chairperson".', 'Assigned To': 'Sala Govindaraj' }
];

const ws = XLSX.utils.json_to_sheet(rows);
const wb = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(wb, ws, 'Tickets');

const outDir = path.join(__dirname, '..', 'sample_data');
fs.mkdirSync(outDir, { recursive: true });
XLSX.writeFile(wb, path.join(outDir, 'fiserv_export.xlsx'));
console.log('✅ sample_data/fiserv_export.xlsx created with 5 sample tickets');
