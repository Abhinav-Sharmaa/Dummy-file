// 02a_export_for_classify.js — Build a Copilot-in-Excel queue
//
// Pulls all rows from the tracker with empty Category and writes them to
// classify_queue.xlsx with the three columns Copilot will fill (Category,
// Effort, AI Summary). Prints the exact Copilot prompt to paste.
//
// Workflow:
//   1. node scripts/02a_export_for_classify.js
//   2. Open classify_queue.xlsx in Excel desktop
//   3. Click Copilot in the ribbon → paste the prompt that was printed
//   4. Review the filled cells → Save
//   5. node scripts/02b_import_classified.js

const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');
const config = require('../config.json');

const QUEUE_PATH = './sample_data/classify_queue.xlsx';

const CATEGORIES = [
  'Banner Update', 'Logo Change', 'Content Edit', 'Contact Info Update',
  'Form Creation', 'Form Edit', 'Page Addition', 'Page Removal',
  'Image Update', 'Bug Fix', 'Other'
];

const COPILOT_PROMPT = `For every row in this table, analyze the "Inquiry Details" column and fill in three columns. Apply to ALL rows.

1) Column "Category" — pick exactly ONE value from this list:
${CATEGORIES.map(c => `   - ${c}`).join('\n')}

2) Column "Effort" — one letter:
   - S = under 30 minutes (text or image swap, contact info update)
   - M = 30 minutes to 2 hours (banner, form edit, new section)
   - L = over 2 hours (new page, complex form, multi-step change)

3) Column "AI Summary" — one sentence under 100 characters that summarizes what the ticket is asking for, in plain English.

Do not modify any other columns. Do not invent data. If the inquiry is unclear, use "Other" and effort "M".`;

function main() {
  const trackerPath = config.paths.tracker;
  if (!fs.existsSync(trackerPath)) {
    console.error(`❌ Tracker not found: ${trackerPath}. Run 01_ingest.js first.`);
    process.exit(1);
  }

  const wb = XLSX.readFile(trackerPath);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: '' });
  const todo = rows.filter(r => !r['Category']);

  if (todo.length === 0) {
    console.log('✅ All tickets are already classified. Nothing to export.');
    return;
  }

  // Build the queue with just the columns Copilot needs to see + fill
  const queue = todo.map(r => ({
    'Inquiry Number':    r['Inquiry Number'],
    'Client Name':       r['Client Name'],
    'Short Description': r['Short Description'],
    'Inquiry Details':   r['Inquiry Details'],
    'Category':          '',
    'Effort':            '',
    'AI Summary':        ''
  }));

  const ws = XLSX.utils.json_to_sheet(queue);
  ws['!cols'] = [
    { wch: 14 }, { wch: 18 }, { wch: 28 }, { wch: 60 }, { wch: 22 }, { wch: 8 }, { wch: 45 }
  ];
  const newWb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(newWb, ws, 'Classify');

  fs.mkdirSync(path.dirname(QUEUE_PATH), { recursive: true });
  XLSX.writeFile(newWb, QUEUE_PATH);

  // Also write the prompt next to the file for easy access
  const promptPath = QUEUE_PATH.replace('.xlsx', '_prompt.txt');
  fs.writeFileSync(promptPath, COPILOT_PROMPT);

  console.log(`📤 Exported ${todo.length} unclassified ticket(s) → ${QUEUE_PATH}`);
  console.log(`\n📋 Next steps:`);
  console.log(`   1. Open ${QUEUE_PATH} in Excel desktop`);
  console.log(`   2. Click the Copilot button in the Home ribbon`);
  console.log(`   3. Paste this prompt (also saved to ${promptPath}):\n`);
  console.log('   ─────────────────── COPILOT PROMPT ───────────────────');
  console.log(COPILOT_PROMPT.split('\n').map(l => '   ' + l).join('\n'));
  console.log('   ───────────────────────────────────────────────────────');
  console.log(`\n   4. Review the filled columns, save the file`);
  console.log(`   5. Run:  node scripts/02b_import_classified.js`);
}

main();
