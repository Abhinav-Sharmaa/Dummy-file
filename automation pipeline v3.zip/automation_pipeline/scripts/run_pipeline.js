// run_pipeline.js — Orchestrator (no emails, with auto-diff)
//
// Each script is standalone; this wrapper just chains them for convenience.
//
// Usage:
//   node scripts/run_pipeline.js intake [path-to-fiserv-export.xlsx]
//   node scripts/run_pipeline.js classify-out      # export queue for Copilot in Excel
//   node scripts/run_pipeline.js classify-in       # after Copilot fills it, import
//   node scripts/run_pipeline.js before <INQUIRY>  # before-screenshots (both envs) + UAT draft
//   node scripts/run_pipeline.js after  <INQUIRY>  # preview after + diff + UAT refresh
//   node scripts/run_pipeline.js deploy <INQUIRY>  # production after + diff + UAT refresh

const { execSync } = require('child_process');
const path = require('path');

const SCRIPTS = path.join(__dirname);

function run(cmd) {
  console.log(`\n$ ${cmd}\n`);
  execSync(cmd, { stdio: 'inherit' });
}

const [, , mode, ...args] = process.argv;

switch (mode) {
  case 'intake':
    if (args[0]) run(`node ${SCRIPTS}/01_ingest.js "${args[0]}"`);
    else         run(`node ${SCRIPTS}/01_ingest.js`);
    break;

  case 'classify-out':
    run(`node ${SCRIPTS}/02a_export_for_classify.js`);
    break;

  case 'classify-in':
    run(`node ${SCRIPTS}/02b_import_classified.js`);
    break;

  case 'before':
    run(`node ${SCRIPTS}/03_screenshot.js ${args[0]} preview before`);
    run(`node ${SCRIPTS}/03_screenshot.js ${args[0]} production before`);
    run(`node ${SCRIPTS}/04_generate_uat.js ${args[0]}`);
    break;

  case 'after':
    run(`node ${SCRIPTS}/03_screenshot.js ${args[0]} preview after`);
    run(`node ${SCRIPTS}/05_diff.js ${args[0]} preview`);
    run(`node ${SCRIPTS}/04_generate_uat.js ${args[0]}`);
    break;

  case 'deploy':
    run(`node ${SCRIPTS}/03_screenshot.js ${args[0]} production after`);
    run(`node ${SCRIPTS}/05_diff.js ${args[0]} production`);
    run(`node ${SCRIPTS}/04_generate_uat.js ${args[0]}`);
    break;

  default:
    console.log(`Usage:
  node scripts/run_pipeline.js intake [export.xlsx]    # ingest fresh Fiserv export
  node scripts/run_pipeline.js classify-out            # export queue → fill in Excel with Copilot
  node scripts/run_pipeline.js classify-in             # after Copilot, import back to tracker
  node scripts/run_pipeline.js before <INQUIRY>        # before-screenshots (preview + prod) + UAT draft
  node scripts/run_pipeline.js after  <INQUIRY>        # preview after-screenshots + auto-diff + UAT refresh
  node scripts/run_pipeline.js deploy <INQUIRY>        # production after-screenshots + auto-diff + UAT refresh
`);
}
