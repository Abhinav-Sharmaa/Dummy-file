// 03_screenshot.js — Capture screenshots at 3 viewports
//
// Usage:
//   node scripts/03_screenshot.js <INQUIRY_NUMBER> <ENV> <PHASE>
//   ENV   = preview | production
//   PHASE = before  | after
//
// Examples:
//   node scripts/03_screenshot.js IP30197749 preview before
//   node scripts/03_screenshot.js IP30197749 preview after
//   node scripts/03_screenshot.js IP30197749 production before
//   node scripts/03_screenshot.js IP30197749 production after
//
// Output: screenshots/<INQUIRY>/<env>_<phase>_<device>.png  (3 files per run)
//
// The script looks up the client's URL from config.json by reading the
// tracker to find Client Name for the inquiry. If your tickets target
// specific pages, append the path after the URL in config or pass --url.

const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const config = require('../config.json');

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? process.argv[i + 1] : fallback;
}

function lookupClientUrl(inquiryNumber, env) {
  const tracker = config.paths.tracker;
  if (!fs.existsSync(tracker)) throw new Error(`Tracker not found: ${tracker}`);
  const wb = XLSX.readFile(tracker);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);
  const row = rows.find(r => String(r['Inquiry Number']).trim() === inquiryNumber);
  if (!row) throw new Error(`Inquiry ${inquiryNumber} not found in tracker`);
  const client = String(row['Client Name']).trim();
  const clientCfg = config.clients[client] || config.clients['DEFAULT'];
  const urlKey = env === 'production' ? 'production_url' : 'preview_url';
  if (!clientCfg[urlKey]) throw new Error(`No ${urlKey} for client ${client}`);
  return { url: clientCfg[urlKey], client };
}

async function captureAt(browser, url, viewport, outPath) {
  const ctx = await browser.newContext({ viewport });
  const page = await ctx.newPage();
  await page.goto(url, { waitUntil: 'networkidle', timeout: 60_000 });
  // Small wait for lazy-loaded images/banners
  await page.waitForTimeout(2000);
  await page.screenshot({ path: outPath, fullPage: true });
  await ctx.close();
}

async function main() {
  const [, , inquiryNumber, env, phase] = process.argv;
  if (!inquiryNumber || !['preview', 'production'].includes(env) || !['before', 'after'].includes(phase)) {
    console.error('Usage: node scripts/03_screenshot.js <INQUIRY> <preview|production> <before|after> [--url <override>]');
    process.exit(1);
  }

  let url, client;
  const override = arg('url');
  if (override) {
    url = override;
    ({ client } = lookupClientUrl(inquiryNumber, env));
  } else {
    ({ url, client } = lookupClientUrl(inquiryNumber, env));
  }

  const outDir = path.join(config.paths.screenshots_dir, inquiryNumber);
  fs.mkdirSync(outDir, { recursive: true });

  console.log(`📸 ${inquiryNumber}  (${client})`);
  console.log(`   ${env}/${phase} → ${url}`);

  const browser = await chromium.launch();
  try {
    for (const [device, viewport] of Object.entries(config.viewports)) {
      const outPath = path.join(outDir, `${env}_${phase}_${device}.png`);
      process.stdout.write(`   ${device.padEnd(7)} ${viewport.width}x${viewport.height}  ... `);
      await captureAt(browser, url, viewport, outPath);
      console.log(`✓ ${path.basename(outPath)}`);
    }
  } finally {
    await browser.close();
  }
  console.log(`✅ Saved to ${outDir}`);
}

main().catch(e => { console.error(`❌ ${e.message}`); process.exit(1); });
