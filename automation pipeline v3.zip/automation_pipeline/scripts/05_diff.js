// 05_diff.js — Generate visual diff images for one inquiry / one environment
//
// Usage: node scripts/05_diff.js <INQUIRY> <preview|production>
//
// For each device (desktop, tablet, mobile) reads the matching
// <env>_before_<device>.png and <env>_after_<device>.png from
// screenshots/<INQUIRY>/ and writes <env>_diff_<device>.png with
// changed pixels highlighted in red.
//
// Handles differing image heights by padding the shorter one with white,
// so full-page screenshots that grew or shrank still compare cleanly.

const fs = require('fs');
const path = require('path');
const { PNG } = require('pngjs');
const pixelmatch = require('pixelmatch');
const config = require('../config.json');

const DEVICES = ['desktop', 'tablet', 'mobile'];

function loadPng(p) {
  if (!fs.existsSync(p)) return null;
  return PNG.sync.read(fs.readFileSync(p));
}

// Return a new PNG sized W×H with src drawn at top-left, rest white.
// If src is already W×H, returns it as-is.
function padTo(src, W, H) {
  if (src.width === W && src.height === H) return src;
  const out = new PNG({ width: W, height: H });
  for (let i = 0; i < out.data.length; i += 4) {
    out.data[i] = 255; out.data[i + 1] = 255; out.data[i + 2] = 255; out.data[i + 3] = 255;
  }
  const copyW = Math.min(src.width, W);
  const copyH = Math.min(src.height, H);
  for (let y = 0; y < copyH; y++) {
    for (let x = 0; x < copyW; x++) {
      const s = (y * src.width + x) * 4;
      const d = (y * W + x) * 4;
      out.data[d]     = src.data[s];
      out.data[d + 1] = src.data[s + 1];
      out.data[d + 2] = src.data[s + 2];
      out.data[d + 3] = src.data[s + 3];
    }
  }
  return out;
}

function main() {
  const [, , inquiryNumber, env] = process.argv;
  if (!inquiryNumber || !['preview', 'production'].includes(env)) {
    console.error('Usage: node scripts/05_diff.js <INQUIRY> <preview|production>');
    process.exit(1);
  }

  const dir = path.join(config.paths.screenshots_dir, inquiryNumber);
  console.log(`🔍 Diffing ${env} screenshots for ${inquiryNumber}`);

  for (const device of DEVICES) {
    const beforePath = path.join(dir, `${env}_before_${device}.png`);
    const afterPath  = path.join(dir, `${env}_after_${device}.png`);
    const diffPath   = path.join(dir, `${env}_diff_${device}.png`);

    const before = loadPng(beforePath);
    const after  = loadPng(afterPath);

    if (!before || !after) {
      console.log(`   ${device.padEnd(7)} — skipped (missing ${!before ? 'before' : 'after'})`);
      continue;
    }

    const W = Math.max(before.width, after.width);
    const H = Math.max(before.height, after.height);
    const b = padTo(before, W, H);
    const a = padTo(after,  W, H);
    const diff = new PNG({ width: W, height: H });

    const changedPx = pixelmatch(b.data, a.data, diff.data, W, H, {
      threshold: 0.1,        // 0 = strict, 1 = lax
      includeAA: false,      // ignore antialiasing wiggle
      diffColor: [255, 0, 0] // red marks the changed pixels
    });

    fs.writeFileSync(diffPath, PNG.sync.write(diff));
    const pct = (changedPx / (W * H) * 100).toFixed(2);
    console.log(`   ${device.padEnd(7)} → ${changedPx.toLocaleString()} px changed (${pct}%)  → ${path.basename(diffPath)}`);
  }
  console.log(`✅ Diffs saved to ${dir}`);
}

main();
