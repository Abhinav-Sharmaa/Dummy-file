// 02b_import_classified.js — Merge Copilot's classifications back into the tracker
//
// Reads classify_queue.xlsx (after Copilot in Excel has filled it) and
// updates the tracker by Inquiry Number. Archives the queue file.

const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');
const config = require('../config.json');

const QUEUE_PATH = './sample_data/classify_queue.xlsx';
const ARCHIVE_DIR = './sample_data/classified_archive';

const VALID_CATEGORIES = new Set([
  'Banner Update', 'Logo Change', 'Content Edit', 'Contact Info Update',
  'Form Creation', 'Form Edit', 'Page Addition', 'Page Removal',
  'Image Update', 'Bug Fix', 'Other'
]);

function todayISO() { return new Date().toISOString().slice(0, 10); }

function main() {
  if (!fs.existsSync(QUEUE_PATH)) {
    console.error(`❌ Queue file not found: ${QUEUE_PATH}.`);
    console.error('   Run 02a_export_for_classify.js first, then process it in Excel.');
    process.exit(1);
  }

  const queueWb = XLSX.readFile(QUEUE_PATH);
  const queueRows = XLSX.utils.sheet_to_json(queueWb.Sheets[queueWb.SheetNames[0]], { defval: '' });

  const tracker = config.paths.tracker;
  const trackerWb = XLSX.readFile(tracker);
  const trackerRows = XLSX.utils.sheet_to_json(trackerWb.Sheets[trackerWb.SheetNames[0]], { defval: '' });
  const trackerById = new Map(trackerRows.map(r => [String(r['Inquiry Number']).trim(), r]));

  let updated = 0, skipped = 0, warnings = [];
  for (const q of queueRows) {
    const id = String(q['Inquiry Number']).trim();
    const target = trackerById.get(id);
    if (!target) { warnings.push(`${id}: not found in tracker`); continue; }

    // Light validation
    if (!q['Category']) { skipped++; continue; }  // Copilot didn't fill this row
    let category = String(q['Category']).trim();
    if (!VALID_CATEGORIES.has(category)) {
      warnings.push(`${id}: unknown category "${category}" → setting to "Other"`);
      category = 'Other';
    }
    let effort = String(q['Effort']).trim().toUpperCase();
    if (!['S', 'M', 'L'].includes(effort)) {
      warnings.push(`${id}: unknown effort "${effort}" → setting to "M"`);
      effort = 'M';
    }
    const summary = String(q['AI Summary']).trim();

    target['Category']    = category;
    target['Effort']      = effort;
    target['AI Summary']  = summary;
    target['Last Updated'] = todayISO();
    updated++;
  }

  const newWs = XLSX.utils.json_to_sheet(trackerRows);
  newWs['!cols'] = Object.keys(trackerRows[0]).map(c => ({ wch: Math.min(Math.max(c.length, 15), 40) }));
  trackerWb.Sheets[trackerWb.SheetNames[0]] = newWs;
  XLSX.writeFile(trackerWb, tracker);

  // Archive the queue file by date so you have an audit trail
  fs.mkdirSync(ARCHIVE_DIR, { recursive: true });
  const archived = path.join(ARCHIVE_DIR, `queue_${todayISO()}_${Date.now()}.xlsx`);
  fs.renameSync(QUEUE_PATH, archived);
  fs.unlinkSync(QUEUE_PATH.replace('.xlsx', '_prompt.txt'));

  console.log(`✅ Imported ${updated} classification(s) into the tracker.`);
  if (skipped) console.log(`   ⏭  Skipped ${skipped} row(s) Copilot didn't fill.`);
  if (warnings.length) {
    console.log(`   ⚠️  ${warnings.length} warning(s):`);
    warnings.forEach(w => console.log(`      - ${w}`));
  }
  console.log(`   📦 Queue archived → ${archived}`);
}

main();
