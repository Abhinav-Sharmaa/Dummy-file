// 04_generate_uat.js — Build the UAT .docx for one inquiry
//
// Usage: node scripts/04_generate_uat.js <INQUIRY_NUMBER>
//
// Produces a Word doc with the exact structure your team uses:
//   Cover
//   Table of Contents
//   1. Ticket Description
//   2. Preview Test Result
//      2.1 Desktop Test Case (Before / After)
//      2.2 Tablet Test Case  (Before / After)
//      2.3 Mobile Test Case  (Before / After)
//   3. Production Test Result
//      3.1 Desktop Test Case (Before / After)
//      3.2 Tablet Test Case  (Before / After)
//      3.3 Mobile Test Case  (Before / After)
//
// Pulls screenshots from screenshots/<INQUIRY>/<env>_<phase>_<device>.png
// (captured by 03_screenshot.js). Missing screenshots become labeled
// placeholders so the tester knows what's pending.

const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');
const {
  Document, Packer, Paragraph, TextRun, ImageRun,
  Header, Footer, AlignmentType, PageOrientation,
  LevelFormat, HeadingLevel, BorderStyle, PageBreak,
  TableOfContents, StyleLevel, PageNumber
} = require('docx');
const config = require('../config.json');

const DEVICES = ['desktop', 'tablet', 'mobile'];
const ENVS = ['preview', 'production'];

// ---------- helpers ----------

function loadTicket(inquiryNumber) {
  const wb = XLSX.readFile(config.paths.tracker);
  const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);
  const ticket = rows.find(r => String(r['Inquiry Number']).trim() === inquiryNumber);
  if (!ticket) throw new Error(`Inquiry ${inquiryNumber} not in tracker`);
  return ticket;
}

function todayPretty() {
  return new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}

function p(text, opts = {}) {
  return new Paragraph({
    children: [new TextRun({ text, ...opts.run })],
    spacing: { after: 120 },
    ...opts.paragraph
  });
}

function h1(text) { return new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(text)], spacing: { before: 240, after: 120 } }); }
function h2(text) { return new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(text)], spacing: { before: 200, after: 100 } }); }
function h3(text) { return new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(text)], spacing: { before: 160, after: 80 } }); }
function emptyP() { return new Paragraph({ children: [new TextRun('')] }); }

function imageParagraph(filePath, maxWidthIn = 6.0, maxHeightIn = 4.5) {
  if (!fs.existsSync(filePath)) {
    // Placeholder so testers see what's missing
    return new Paragraph({
      children: [new TextRun({ text: `[ Screenshot pending: ${path.basename(filePath)} ]`, italics: true, color: '888888' })],
      spacing: { before: 60, after: 60 }
    });
  }
  const data = fs.readFileSync(filePath);
  // Read PNG dimensions from header (bytes 16-23, big-endian width then height).
  let widthPx = 1200, heightPx = 800;
  if (data[0] === 0x89 && data.slice(1, 4).toString() === 'PNG') {
    widthPx  = data.readUInt32BE(16);
    heightPx = data.readUInt32BE(20);
  }
  // Fit inside maxWidth × maxHeight box, preserving aspect ratio.
  const aspect = widthPx / heightPx;
  let displayW = maxWidthIn;
  let displayH = displayW / aspect;
  if (displayH > maxHeightIn) {
    displayH = maxHeightIn;
    displayW = displayH * aspect;
  }
  return new Paragraph({
    children: [new ImageRun({
      data,
      transformation: { width: displayW * 96, height: displayH * 96 }, // docx-js wants px at 96 DPI
      type: 'png'
    })],
    spacing: { before: 60, after: 120 },
    alignment: AlignmentType.CENTER
  });
}

function testCaseBlock(inquiryNumber, env, device, sectionNum) {
  const screensDir = path.join(config.paths.screenshots_dir, inquiryNumber);
  const beforePath = path.join(screensDir, `${env}_before_${device}.png`);
  const afterPath  = path.join(screensDir, `${env}_after_${device}.png`);
  const diffPath   = path.join(screensDir, `${env}_diff_${device}.png`);
  return [
    h3(`${sectionNum} ${device.charAt(0).toUpperCase() + device.slice(1)} Test Case`),
    p('Before:', { run: { bold: true } }),
    imageParagraph(beforePath),
    p('After:',  { run: { bold: true } }),
    imageParagraph(afterPath),
    p('Diff (red = changed pixels):', { run: { bold: true } }),
    imageParagraph(diffPath),
    emptyP()
  ];
}

function envSection(inquiryNumber, env, topNum) {
  const title = env === 'preview' ? 'Preview Test Result' : 'Production Test Result';
  const children = [h1(`${topNum}. ${title}`)];
  DEVICES.forEach((device, i) => {
    children.push(...testCaseBlock(inquiryNumber, env, device, `${topNum}.${i + 1}`));
  });
  return children;
}

function coverPage(ticket) {
  return [
    new Paragraph({ children: [new TextRun({ text: 'Web Hosting', size: 28, color: '666666' })], alignment: AlignmentType.CENTER, spacing: { before: 1200, after: 240 } }),
    new Paragraph({ children: [new TextRun({ text: 'UAT Document', size: 48, bold: true })], alignment: AlignmentType.CENTER, spacing: { after: 480 } }),
    new Paragraph({ children: [new TextRun({ text: ticket['Client Name'], size: 32, bold: true })], alignment: AlignmentType.CENTER, spacing: { after: 120 } }),
    new Paragraph({ children: [new TextRun({ text: `Inquiry: ${ticket['Inquiry Number']}`, size: 24 })], alignment: AlignmentType.CENTER, spacing: { after: 120 } }),
    new Paragraph({ children: [new TextRun({ text: `Assigned to: ${ticket['Assigned To'] || '—'}`, size: 22 })], alignment: AlignmentType.CENTER, spacing: { after: 120 } }),
    new Paragraph({ children: [new TextRun({ text: `Date: ${todayPretty()}`, size: 22 })], alignment: AlignmentType.CENTER, spacing: { after: 480 } }),
    new Paragraph({ children: [new PageBreak()] })
  ];
}

function tocPage() {
  return [
    h1('Table of Contents'),
    new TableOfContents('Contents', {
      hyperlink: true,
      headingStyleRange: '1-3',
      stylesWithLevels: [
        new StyleLevel('Heading1', 1),
        new StyleLevel('Heading2', 2),
        new StyleLevel('Heading3', 3)
      ]
    }),
    new Paragraph({ children: [new PageBreak()] })
  ];
}

function ticketDescriptionSection(ticket) {
  return [
    h1('1. Ticket Description'),
    p('Client:', { run: { bold: true } }),
    p(ticket['Client Name'] || ''),
    p('Inquiry Number:', { run: { bold: true } }),
    p(String(ticket['Inquiry Number'] || '')),
    p('Short Description:', { run: { bold: true } }),
    p(ticket['Short Description'] || ''),
    p('Category / Effort:', { run: { bold: true } }),
    p(`${ticket['Category'] || '—'}  /  ${ticket['Effort'] || '—'}`),
    p('AI Summary:', { run: { bold: true } }),
    p(ticket['AI Summary'] || '—'),
    p('Full Inquiry Details:', { run: { bold: true } }),
    p(ticket['Inquiry Details'] || ''),
    new Paragraph({ children: [new PageBreak()] })
  ];
}

// ---------- main ----------

async function main() {
  const inquiryNumber = process.argv[2];
  if (!inquiryNumber) {
    console.error('Usage: node scripts/04_generate_uat.js <INQUIRY_NUMBER>');
    process.exit(1);
  }

  const ticket = loadTicket(inquiryNumber);
  console.log(`📄 Building UAT for ${inquiryNumber} (${ticket['Client Name']})`);

  const doc = new Document({
    creator: 'Web Hosting Automation',
    title: `UAT — ${ticket['Client Name']} — ${inquiryNumber}`,
    features: { updateFields: true },  // forces Word to refresh the TOC on open
    styles: {
      default: { document: { run: { font: 'Arial', size: 22 } } },
      paragraphStyles: [
        { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
          run: { size: 32, bold: true, font: 'Arial', color: '1F3A5F' },
          paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 0 } },
        { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
          run: { size: 28, bold: true, font: 'Arial', color: '1F3A5F' },
          paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 1 } },
        { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true,
          run: { size: 24, bold: true, font: 'Arial' },
          paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 2 } }
      ]
    },
    sections: [{
      properties: {
        page: {
          size: { width: 12240, height: 15840 }, // US Letter
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
        }
      },
      headers: {
        default: new Header({ children: [
          new Paragraph({ children: [new TextRun({ text: `UAT — ${ticket['Inquiry Number']}  •  ${ticket['Client Name']}`, size: 18, color: '888888' })], alignment: AlignmentType.RIGHT })
        ]})
      },
      footers: {
        default: new Footer({ children: [
          new Paragraph({ children: [new TextRun({ children: ['Page ', PageNumber.CURRENT, ' of ', PageNumber.TOTAL_PAGES], size: 18, color: '888888' })], alignment: AlignmentType.CENTER })
        ]})
      },
      children: [
        ...coverPage(ticket),
        ...tocPage(),
        ...ticketDescriptionSection(ticket),
        ...envSection(inquiryNumber, 'preview', 2),
        new Paragraph({ children: [new PageBreak()] }),
        ...envSection(inquiryNumber, 'production', 3)
      ]
    }]
  });

  const safeClient = String(ticket['Client Name']).replace(/[^A-Za-z0-9]+/g, '_');
  const outPath = path.join(config.paths.uat_docs_dir, `UAT_${inquiryNumber}_${safeClient}.docx`);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });

  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(outPath, buffer);

  // Update tracker with UAT path
  const wb = XLSX.readFile(config.paths.tracker);
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(ws);
  const row = rows.find(r => String(r['Inquiry Number']).trim() === inquiryNumber);
  if (row) {
    row['UAT Doc Path'] = outPath;
    row['Status'] = row['Status'] === 'New' ? 'In Progress' : row['Status'];
    row['Last Updated'] = new Date().toISOString().slice(0, 10);
    wb.Sheets[wb.SheetNames[0]] = XLSX.utils.json_to_sheet(rows);
    XLSX.writeFile(wb, config.paths.tracker);
  }

  console.log(`✅ UAT doc → ${outPath}`);
  console.log(`   Open in Word and right-click the TOC → "Update Field" to refresh page numbers.`);
}

main().catch(e => { console.error(`❌ ${e.message}\n${e.stack}`); process.exit(1); });
