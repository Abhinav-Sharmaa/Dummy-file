# Web Hosting Ticket Automation Pipeline
### Microsoft Copilot edition with auto-diff validation

End-to-end automation for the daily ticket → website change → UAT doc workflow.
Runs entirely on your office laptop using **Node.js (local) + M365 Copilot (Excel)**.
No external AI APIs, no Power Automate, no client emails — pure internal-team automation.

---

## Architecture

| Stage | Where it runs | What it does |
|-------|---------------|--------------|
| 1. Ingest | Node script (local) | Reads Fiserv Excel export, appends new tickets to tracker, dedupes |
| 2a. Export to classify | Node script (local) | Builds `classify_queue.xlsx` containing only unclassified tickets |
| 2. Classify | **Copilot in Excel** | One prompt fills Category, Effort, AI Summary for every row |
| 2b. Import classified | Node script (local) | Merges Copilot's classifications back into the tracker |
| 3. Screenshots | Node + Playwright (local) | Full-page captures at Desktop / Tablet / Mobile |
| 4. UAT Word doc | Node script (local) | Cover, TOC, ticket description, Preview & Production sections (3 devices each: Before / After / Diff) |
| 5. Visual diff | Node script (local) | Pixel-compares before/after, highlights changed regions in red |

**Realistic time savings per ticket: ~30–35 min**, mostly from screenshots + UAT doc + automated diff.

---

## The two-command workflow per ticket

```bash
# Before you start work
node scripts/run_pipeline.js before IP30197749
#   → captures preview + production "before" screenshots (3 viewports each)
#   → drafts the UAT doc with Before images in place (diff sections show "pending")

# ... you make the actual website change in preview ...

# When preview change is ready
node scripts/run_pipeline.js after IP30197749
#   → captures preview "after" screenshots
#   → runs pixel diff → produces 3 red-highlighted diff images
#   → refreshes UAT doc (preview section now fully populated)

# ... after you deploy to production ...

node scripts/run_pipeline.js deploy IP30197749
#   → captures production "after" screenshots
#   → runs production diff
#   → refreshes UAT doc (final version, all sections complete)
```

**That's it.** Two commands when you start, one when preview is ready, one after deploy.

---

## What the diff does for you

Without the diff, self-validation means flipping between two browser windows comparing pixels by eye on three devices — easy to miss subtle regressions like a footer link that shifted or a sidebar that lost padding.

The diff image overlays Before and After and paints every changed pixel red. Three things become obvious in 2 seconds:

1. **The intended change** shows up as a red blob exactly where you expected it.
2. **Unintended changes** show up as unexpected red blobs elsewhere (the most common regression catch).
3. **Nothing changed = nothing red.** If you ran the wrong inquiry's screenshots, you'll see it instantly.

The diff appears in the UAT doc under each device test case, right after Before and After.

---

## Morning ingest + classify (runs once per day)

```bash
# 1. Export tickets from Fiserv as Excel, save anywhere
node scripts/run_pipeline.js intake C:\Users\you\Downloads\fiserv_export.xlsx

# 2. Build the Copilot queue
node scripts/run_pipeline.js classify-out

# 3. In Excel desktop: open classify_queue.xlsx → Copilot button → paste the printed prompt → save

# 4. Merge results back into tracker
node scripts/run_pipeline.js classify-in
```

---

## One-time setup

```bash
# 1. Install Node.js 18+ (from nodejs.org) — needs IT approval at some orgs
node --version

# 2. Install dependencies
npm install

# 3. Install Chromium for Playwright
npx playwright install chromium

# 4. Copy and fill in config
cp config.example.json config.json
# Edit config.json:
#   - clients: add preview_url + production_url per client
#   - viewports: tweak if you target different device sizes
```

No API keys to manage. Nothing leaves your laptop except Playwright loading client websites (same calls your browser already makes).

---

## What each script does

| Script | Purpose |
|--------|---------|
| `01_ingest.js` | Read Fiserv export, append new tickets, dedupe by Inquiry Number |
| `02a_export_for_classify.js` | Build `classify_queue.xlsx` for Copilot in Excel |
| `02b_import_classified.js` | Merge filled queue back into tracker, archive the queue |
| `03_screenshot.js` | Playwright: capture full-page at 3 viewports for one env/phase |
| `04_generate_uat.js` | Build UAT.docx with cover, TOC, all screenshot + diff slots |
| `05_diff.js` | Pixel-diff before vs after for one env, output 3 red-highlighted PNGs |
| `run_pipeline.js` | Convenience wrapper that chains the above |
| `build_sample.js` | Generate a sample Fiserv export for testing |

---

## Project layout

```
automation_pipeline/
├── README.md
├── config.example.json
├── package.json
├── copilot_prompts/
│   └── README.md                       # Copilot prompt reference
├── scripts/
│   ├── 01_ingest.js
│   ├── 02a_export_for_classify.js
│   ├── 02b_import_classified.js
│   ├── 03_screenshot.js
│   ├── 04_generate_uat.js
│   ├── 05_diff.js
│   ├── run_pipeline.js
│   └── build_sample.js
├── sample_data/
│   ├── fiserv_export.xlsx              # sample input
│   ├── tracker.xlsx                    # auto-created
│   ├── classify_queue.xlsx             # transient, archived after import
│   └── classified_archive/             # daily audit trail
├── screenshots/<INQUIRY>/              # captured PNGs (18 per ticket when complete:
│                                       #   <env>_<phase>_<device>.png for each combination)
└── uat_docs/                           # generated Word docs
```

---

## Quick test (no Copilot needed)

You can validate everything except classification right now:

```bash
npm install
node scripts/build_sample.js               # creates sample Fiserv export
node scripts/01_ingest.js                  # creates tracker.xlsx
node scripts/04_generate_uat.js IP30197749 # generates UAT doc with placeholder screenshots
```

Open the generated `.docx` in Word → right-click the TOC → **Update Field**.

For real screenshots + diff:
```bash
npx playwright install chromium
node scripts/03_screenshot.js IP30197749 preview before
# ... change the site ...
node scripts/03_screenshot.js IP30197749 preview after
node scripts/05_diff.js IP30197749 preview
node scripts/04_generate_uat.js IP30197749
```

---

## Configuration notes

**Per-client URLs.** Each client in `config.json` needs `preview_url` and `production_url`. The screenshot script looks these up by exact match on `Client Name` from the tracker. A `DEFAULT` entry catches unmapped clients.

**Target specific pages.** For a ticket about `/loans/auto`:
```bash
node scripts/03_screenshot.js IP30194877 preview before --url https://preview.communityfin.example.com/loans/auto
```

**Authentication.** If preview sites require login, edit `03_screenshot.js` → `browser.newContext({ httpCredentials: {...} })` or implement a one-time login and save `storageState` for reuse.

**Diff sensitivity.** In `05_diff.js`, `threshold: 0.1` is moderate — `0` is strictest (catches antialiasing wiggle), `1` is most lax (only flags large color changes). Tune per your false-positive tolerance.

---

## Cost & runtime

- **No API costs** — everything runs on your machine and your existing M365 Copilot license.
- **Wall-clock automation per ticket:** ~90 seconds (screenshots are the slowest stage at ~30 sec per environment, diff adds ~5 sec total).
- **Manual time eliminated:** ~30–35 min per ticket (screenshots + doc + visual checking).

20 tickets/day × 30 min saved = **10 hours of manual work removed per day across the team.**

---

## What's still manual

- **The actual website change.** Your devs make code edits. GitHub Copilot is great here — speeds up typing, doesn't replace judgment.
- **Final sign-off on the UAT doc.** The diff makes it fast (2 seconds per device instead of 5 minutes), but a human still confirms.
- **Triggering screenshots when a dev finishes.** Run `after` and `deploy` manually. If you have a deploy script, you can chain a call at the end of it.
