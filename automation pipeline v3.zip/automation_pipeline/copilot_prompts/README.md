# Copilot Prompt Library

The one Copilot interaction in this pipeline: classifying a batch of tickets in Excel.
The `02a_export_for_classify.js` script prints this prompt automatically — this file is
a reference if you ever want to run it manually or tweak it.

---

## Classify a batch of tickets — Copilot in Excel

**Where:** Open `classify_queue.xlsx` in Excel desktop → Home ribbon → **Copilot** → paste:

```
For every row in this table, analyze the "Inquiry Details" column and fill in three columns. Apply to ALL rows.

1) Column "Category" — pick exactly ONE value from this list:
   - Banner Update
   - Logo Change
   - Content Edit
   - Contact Info Update
   - Form Creation
   - Form Edit
   - Page Addition
   - Page Removal
   - Image Update
   - Bug Fix
   - Other

2) Column "Effort" — one letter:
   - S = under 30 minutes (text or image swap, contact info update)
   - M = 30 minutes to 2 hours (banner, form edit, new section)
   - L = over 2 hours (new page, complex form, multi-step change)

3) Column "AI Summary" — one sentence under 100 characters that summarizes what the ticket is asking for, in plain English.

Do not modify any other columns. Do not invent data. If the inquiry is unclear, use "Other" and effort "M".
```

**Tip:** If Copilot pauses after a few rows, prompt it: "continue filling the remaining rows." Save the file when done.

---

## Bonus: Daily standup summary (ad hoc)

After running ingest + classify, paste this into Copilot in Excel on `tracker.xlsx`:

```
Summarize the tickets received today. Group by Category and by Assigned To. Highlight any "L" effort tickets that need attention first. Output as a short status I can paste into a standup message — no tables, just plain text under 200 words.
```

---

## Bonus: GitHub Copilot for the actual change

When you're in VS Code making the website change, ask GitHub Copilot inline:

```
The client wants this change to their Fiserv CUSCD site:
[paste Inquiry Details from the tracker]

Suggest the simplest implementation. If this matches a recurring pattern (banner swap, logo update, contact info change), point me to the template files to edit.
```
