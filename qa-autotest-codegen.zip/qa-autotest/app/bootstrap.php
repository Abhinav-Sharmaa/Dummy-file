<?php
declare(strict_types=1);

define('ROOT_DIR',   dirname(__DIR__));
define('DATA_DIR',   ROOT_DIR . '/data');
define('RUNS_DIR',   DATA_DIR . '/runs');
define('RUNNER_DIR', ROOT_DIR . '/runner');
define('ARTIFACTS_DIR', ROOT_DIR . '/public/artifacts');
define('RECORDINGS_DIR', DATA_DIR . '/recordings');
define('NODE_BIN',   getenv('QA_NODE_BIN') ?: 'node');

require_once __DIR__ . '/Storage.php';
require_once __DIR__ . '/RecordingParser.php';
require_once __DIR__ . '/TestCaseGenerator.php';
require_once __DIR__ . '/Runner.php';

function json_out(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

function json_fail(string $message, int $status = 400): never
{
    json_out(['ok' => false, 'error' => $message], $status);
}

function read_json_body(): array
{
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function new_run_id(): string
{
    return date('Ymd-His') . '-' . substr(bin2hex(random_bytes(3)), 0, 6);
}

function valid_run_id(string $id): bool
{
    return (bool) preg_match('/^[0-9]{8}-[0-9]{6}-[a-f0-9]{6}$/', $id);
}

function new_recording_token(): string
{
    return 'rec-' . date('YmdHis') . '-' . substr(bin2hex(random_bytes(3)), 0, 6);
}

function valid_recording_token(string $token): bool
{
    return (bool) preg_match('/^rec-[0-9]{14}-[a-f0-9]{6}$/', $token);
}
