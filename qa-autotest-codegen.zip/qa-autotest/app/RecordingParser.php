<?php
declare(strict_types=1);

/**
 * Parses a `playwright codegen --target javascript` recording into:
 *   - actions[]  : sanitized, executable one-line Playwright statements
 *   - steps[]    : human-readable step text, aligned 1:1 with actions
 *   - usesFrameLocator : whether the recording already covers iframe context
 *
 * Sanitizing: only allow-listed Playwright methods survive; anything that
 * could reach Node APIs, the file system, or arbitrary code is dropped.
 */
final class RecordingParser
{
    private const ALLOWED_METHODS = [
        // navigation + actions
        'goto', 'click', 'dblclick', 'fill', 'press', 'check', 'uncheck',
        'selectOption', 'hover', 'focus', 'clear', 'setChecked', 'tap',
        // locator builders
        'getByRole', 'getByText', 'getByLabel', 'getByPlaceholder',
        'getByAltText', 'getByTitle', 'getByTestId', 'locator', 'frameLocator',
        'contentFrame', 'first', 'last', 'nth', 'filter', 'or', 'and',
        // assertions
        'toBeVisible', 'toBeHidden', 'toHaveText', 'toContainText',
        'toHaveValue', 'toHaveCount', 'toBeChecked', 'toHaveAttribute',
        'toHaveURL', 'toHaveTitle', 'toBeEnabled', 'toBeDisabled', 'toBeEmpty',
    ];

    private const DENY_PATTERN =
        '/`|=>|\brequire\b|\bimport\s|\bprocess\b|\bfs\b|\beval\b|\bFunction\b|' .
        '\bevaluate\b|\bexposeFunction\b|\baddInitScript\b|\broute\b|' .
        '\bsetInputFiles\b|\bwaitForEvent\b|\bon\(|\bonce\(|\$\{/u';

    /** @return array{actions: string[], steps: string[], usesFrameLocator: bool} */
    public static function parse(string $source): array
    {
        $actions = [];
        $steps = [];
        $buffer = '';

        foreach (preg_split('/\R/', $source) ?: [] as $raw) {
            $line = trim($raw);
            if ($line === '' || str_starts_with($line, '//')) {
                continue;
            }
            // Skip wrapper noise from codegen output.
            if (preg_match('/^(import\s|const\s.*=\s*require|test\(|test\.describe|\}\);?$|\};?$)/', $line)) {
                continue;
            }
            $buffer .= ($buffer === '' ? '' : ' ') . $line;
            if (!str_ends_with($buffer, ';')) {
                continue; // statement continues on next line
            }
            $stmt = $buffer;
            $buffer = '';
            if (self::isSafe($stmt)) {
                $actions[] = $stmt;
                $steps[] = self::humanize($stmt);
            }
        }

        return [
            'actions' => $actions,
            'steps' => $steps,
            'usesFrameLocator' => (bool) preg_grep('/frameLocator|contentFrame/', $actions),
        ];
    }

    private static function isSafe(string $stmt): bool
    {
        if (!preg_match('/^await (page|expect)\b/', $stmt)) {
            return false;
        }
        if (preg_match(self::DENY_PATTERN, $stmt)) {
            return false;
        }
        preg_match_all('/\.([A-Za-z_][A-Za-z0-9_]*)\s*\(/', $stmt, $m);
        foreach ($m[1] as $method) {
            if (!in_array($method, self::ALLOWED_METHODS, true)) {
                return false;
            }
        }
        return true;
    }

    private static function humanize(string $stmt): string
    {
        $q = "'((?:[^'\\\\]|\\\\.)*)'";
        $inFrame = preg_match('/frameLocator|contentFrame/', $stmt) ? '[widget iframe] ' : '';
        $target = self::targetName($stmt);

        if (preg_match("/page\.goto\({$q}/", $stmt, $m)) {
            return "Navigate to {$m[1]}";
        }
        if (preg_match("/\.fill\({$q}\)/", $stmt, $m)) {
            $value = preg_match('/pass|security ?code|pin/i', $target)
                ? '•••'
                : "'" . $m[1] . "'";
            return "{$inFrame}Fill {$target} with {$value}";
        }
        if (str_contains($stmt, '.dblclick(')) {
            return "{$inFrame}Double-click {$target}";
        }
        if (str_contains($stmt, '.click(') || str_contains($stmt, '.tap(')) {
            return "{$inFrame}Click {$target}";
        }
        if (preg_match("/\.press\({$q}\)/", $stmt, $m)) {
            return "{$inFrame}Press {$m[1]} on {$target}";
        }
        if (str_contains($stmt, '.check(') || preg_match('/setChecked\(\s*true/', $stmt)) {
            return "{$inFrame}Check {$target}";
        }
        if (str_contains($stmt, '.uncheck(') || preg_match('/setChecked\(\s*false/', $stmt)) {
            return "{$inFrame}Uncheck {$target}";
        }
        if (preg_match("/\.selectOption\({$q}\)/", $stmt, $m)) {
            return "{$inFrame}Select '{$m[1]}' in {$target}";
        }
        if (str_starts_with($stmt, 'await expect')) {
            if (preg_match("/\.toContainText\({$q}\)|\.toHaveText\({$q}\)/", $stmt, $m)) {
                $text = $m[1] !== '' ? $m[1] : ($m[2] ?? '');
                return "{$inFrame}Assert {$target} shows '{$text}'";
            }
            if (str_contains($stmt, '.toBeVisible(')) {
                return "{$inFrame}Assert {$target} is visible";
            }
            if (preg_match("/\.toHaveValue\({$q}\)/", $stmt, $m)) {
                return "{$inFrame}Assert {$target} has value '{$m[1]}'";
            }
            if (preg_match("/\.toHaveURL\(/", $stmt)) {
                return 'Assert the page URL matches the recorded expectation';
            }
            return "{$inFrame}Assert: {$target}";
        }
        return "{$inFrame}Run recorded action: " . $stmt;
    }

    /** Best-effort element name for step text. */
    private static function targetName(string $stmt): string
    {
        $q = "'((?:[^'\\\\]|\\\\.)*)'";
        if (preg_match("/getByRole\(\s*{$q}\s*,\s*\{\s*name:\s*{$q}/", $stmt, $m)) {
            return "the '{$m[2]}' {$m[1]}";
        }
        if (preg_match("/getByRole\(\s*{$q}\s*\)/", $stmt, $m)) {
            return "the {$m[1]}";
        }
        if (preg_match("/getByLabel\(\s*{$q}/", $stmt, $m)) {
            return "'{$m[1]}'";
        }
        if (preg_match("/getByPlaceholder\(\s*{$q}/", $stmt, $m)) {
            return "the '{$m[1]}' field";
        }
        if (preg_match("/getByText\(\s*{$q}/", $stmt, $m)) {
            return "text '{$m[1]}'";
        }
        if (preg_match("/getByTestId\(\s*{$q}/", $stmt, $m)) {
            return "[data-testid={$m[1]}]";
        }
        if (preg_match("/locator\(\s*{$q}/", $stmt, $m)) {
            return "'{$m[1]}'";
        }
        return 'the element';
    }
}
