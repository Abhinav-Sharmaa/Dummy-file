/* QA Bench frontend — vanilla JS, talks to api.php. */
"use strict";

const $ = (sel, el = document) => el.querySelector(sel);
const DEVICES = ["desktop", "tablet", "mobile"];
const DEVICE_LABEL = { desktop: "Desktop 1920×1080", tablet: "Tablet 768×1024", mobile: "Mobile 375×812" };

let run = null;
let pollTimer = null;
let editing = new Set();
let recording = null; // { token, ready, actions }
let recTimer = null;

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function api(action, payload) {
  const res = await fetch(`api.php?action=${action}`, {
    method: payload ? "POST" : "GET",
    headers: { "Content-Type": "application/json" },
    body: payload ? JSON.stringify(payload) : undefined,
  });
  const data = await res.json().catch(() => ({ ok: false, error: "Bad response" }));
  if (!data.ok) throw new Error(data.error || "Request failed");
  return data;
}

/* ---------- record (codegen) ---------- */

$("#btn-record").addEventListener("click", async () => {
  const hint = $("#rec-hint");
  try {
    const { token } = await api("record_start", { url: $("#url").value });
    recording = { token, ready: false, actions: 0 };
    hint.textContent = "Recorder launching in Chrome… click through the flow, then CLOSE the recorder window.";
    clearInterval(recTimer);
    recTimer = setInterval(async () => {
      try {
        const st = await api("record_status", { token: recording.token });
        if (st.ready) {
          clearInterval(recTimer);
          recording.ready = true;
          recording.actions = st.actions;
          hint.textContent = `Recording ready — ${st.actions} action(s) captured. It will drive the next Generate.`;
        }
      } catch { /* keep polling */ }
    }, 2000);
  } catch (e) { hint.textContent = e.message; }
});

/* ---------- generate ---------- */

$("#btn-generate").addEventListener("click", async () => {
  const btn = $("#btn-generate"), hint = $("#gen-hint");
  hint.textContent = "";
  btn.disabled = true; btn.textContent = "Generating…";
  try {
    const payload = { ticket: $("#ticket").value, url: $("#url").value };
    if (recording?.ready) payload.recording_token = recording.token;
    const data = await api("generate", payload);
    if (recording?.ready) {
      $("#rec-hint").textContent = `Generated from recording (${recording.actions} actions). Record again to replace it.`;
      recording = null;
    }
    setRun(data.run);
    history.replaceState(null, "", `?run=${data.run.id}`);
    $("#panel-review").scrollIntoView({ behavior: "smooth" });
  } catch (e) {
    hint.textContent = e.message;
  } finally {
    btn.disabled = false; btn.textContent = "Generate test cases";
  }
});

/* ---------- state + render ---------- */

function setRun(next) {
  run = next;
  editing = new Set([...editing].filter((id) => run.cases.some((c) => c.id === id)));
  $("#panel-review").classList.remove("hidden");
  $("#run-id-badge").textContent = `run ${run.id} · ${run.url}`;
  renderCases();
  renderResults();
}

function renderCases() {
  const locked = run.status === "running";
  $("#cases").innerHTML = run.cases.map((c) => editing.has(c.id) ? editView(c) : caseView(c, locked)).join("");
  bindCaseButtons();
  const approved = run.cases.filter((c) => c.status === "approved").length;
  const btn = $("#btn-run");
  btn.disabled = locked || approved === 0;
  btn.textContent = locked ? "Running…" : `Run ${approved || ""} approved case${approved === 1 ? "" : "s"}`.replace("  ", " ");
  $("#run-hint").textContent = locked ? "Cases are locked while the runner executes." :
    approved === 0 ? "Approve at least one case to enable execution." : "";
}

function caseView(c, locked) {
  const li = (items) => items.map((x) => `<li>${esc(x)}</li>`).join("");
  return `
  <article class="case" data-status="${esc(c.status)}" data-id="${esc(c.id)}">
    <div class="case-top">
      <span class="case-id">${esc(c.id)}</span>
      <span class="case-title">${esc(c.title)}</span>
      ${c.type === "recorded" ? `<span class="chip mono">recorded · ${(c.actions || []).length} actions</span>` : ""}
      ${c.edited ? '<span class="edited-flag">edited</span>' : ""}
      <span class="status-pill ${esc(c.status)}">${esc(c.status)}</span>
    </div>
    <dl>
      <dt>Preconditions</dt><dd><ul>${li(c.preconditions)}</ul></dd>
      <dt>Steps</dt><dd><ol>${li(c.steps)}</ol></dd>
      <dt>Expected result</dt><dd>${esc(c.expected)}</dd>
    </dl>
    <div class="case-devices">
      ${c.devices.map((d) => `<span class="chip mono">${esc(DEVICE_LABEL[d] || d)}</span>`).join("")}
    </div>
    ${locked ? "" : `
    <div class="case-actions">
      <button class="btn small approve" data-act="approved">Approve</button>
      <button class="btn small" data-act="edit">Edit</button>
      <button class="btn small reject" data-act="rejected">Reject</button>
    </div>`}
  </article>`;
}

function editView(c) {
  const lines = (a) => esc(a.join("\n"));
  return `
  <article class="case edit" data-status="pending" data-id="${esc(c.id)}">
    <div class="case-top">
      <span class="case-id">${esc(c.id)}</span>
      <span class="status-pill pending">editing</span>
    </div>
    <div class="field"><label>Title</label><input data-f="title" value="${esc(c.title)}"></div>
    <div class="field"><label>Preconditions — one per line</label><textarea data-f="preconditions" rows="3">${lines(c.preconditions)}</textarea></div>
    <div class="field"><label>Steps — one per line</label><textarea data-f="steps" rows="6">${lines(c.steps)}</textarea></div>
    <div class="field"><label>Expected result</label><textarea data-f="expected" rows="3">${esc(c.expected)}</textarea></div>
    <p class="hint">Devices are fixed by policy: every case runs on desktop, tablet and mobile. Saving regenerates the Playwright script and resets the case to pending.${c.type === "recorded" ? " Note: editing a recorded case switches it to the generic (non-replay) template — re-record to change the captured flow." : ""}</p>
    <div class="case-actions">
      <button class="btn small primary" data-act="save">Save changes</button>
      <button class="btn small" data-act="cancel">Cancel</button>
    </div>
  </article>`;
}

function bindCaseButtons() {
  $("#cases").querySelectorAll("[data-act]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const card = btn.closest(".case");
      const caseId = card.dataset.id;
      const act = btn.dataset.act;
      try {
        if (act === "edit")   { editing.add(caseId); renderCases(); return; }
        if (act === "cancel") { editing.delete(caseId); renderCases(); return; }
        if (act === "save") {
          const val = (f) => card.querySelector(`[data-f="${f}"]`).value;
          const split = (f) => val(f).split("\n");
          const data = await api("save_case", {
            run_id: run.id, case_id: caseId,
            title: val("title"), expected: val("expected"),
            preconditions: split("preconditions"), steps: split("steps"),
          });
          editing.delete(caseId);
          setRun(data.run);
          return;
        }
        const data = await api("set_status", { run_id: run.id, case_id: caseId, status: act });
        setRun(data.run);
      } catch (e) { alert(e.message); }
    });
  });
}

/* ---------- execute + poll ---------- */

$("#btn-run").addEventListener("click", async () => {
  try {
    const data = await api("execute", { run_id: run.id });
    setRun(data.run);
    startPolling();
    $("#panel-results").scrollIntoView({ behavior: "smooth" });
  } catch (e) { alert(e.message); }
});

function startPolling() {
  clearInterval(pollTimer);
  pollTimer = setInterval(async () => {
    try {
      const data = await api("status", { run_id: run.id });
      run = data.run;
      renderCases();
      renderResults(data.progress);
      if (run.status !== "running") clearInterval(pollTimer);
    } catch { /* transient; keep polling */ }
  }, 2000);
}

/* ---------- results matrix ---------- */

function renderResults(progress) {
  const approved = run.cases.filter((c) => c.status === "approved");
  const hasAny = run.status === "running" || run.status === "done" || run.status === "error" ||
                 Object.keys(run.results || {}).length > 0;
  $("#panel-results").classList.toggle("hidden", !hasAny);
  if (!hasAny) return;

  $("#log-link").href = `api.php?action=log&run_id=${run.id}`;
  const hint = $("#results-hint");
  if (run.status === "running") {
    hint.textContent = progress?.message || "Executing approved cases across 3 device profiles…";
  } else if (run.status === "error") {
    hint.textContent = "Runner failed — open the runner log below.";
  } else {
    const cells = approved.length * DEVICES.length;
    const passed = approved.reduce((n, c) =>
      n + DEVICES.filter((d) => run.results?.[c.id]?.[d]?.status === "pass").length, 0);
    hint.textContent = `Finished: ${passed}/${cells} device runs passed.`;
  }

  const cell = (c, d) => {
    const r = run.results?.[c.id]?.[d];
    if (!r) return `<span class="badge ${run.status === "running" ? "running" : "idle"}">${run.status === "running" ? "…" : "—"}</span>`;
    const badge = `<span class="badge ${r.status === "pass" ? "pass" : "fail"}">${r.status.toUpperCase()}</span>`;
    const note = r.status === "fail" && r.error ? `<span class="cell-note">${esc(r.error)}</span>` : "";
    const shot = r.screenshot ? `<a class="shot-link" href="${esc(r.screenshot)}" target="_blank" rel="noopener">failure screenshot</a>` : "";
    return badge + note + shot;
  };

  $("#matrix").innerHTML = `
  <div class="matrix-wrap"><table class="matrix">
    <thead><tr><th>Case</th>${DEVICES.map((d) => `<th>${esc(DEVICE_LABEL[d])}</th>`).join("")}</tr></thead>
    <tbody>
      ${approved.map((c) => `
      <tr>
        <td class="tc">${esc(c.id)}<span class="cell-note">${esc(c.title)}</span></td>
        ${DEVICES.map((d) => `<td>${cell(c, d)}</td>`).join("")}
      </tr>`).join("")}
    </tbody>
  </table></div>`;
}

/* ---------- boot ---------- */

(async function boot() {
  try {
    const { runs } = await api("runs");
    if (runs.length) {
      $("#recent-runs").innerHTML = "recent: " + runs.slice(0, 5)
        .map((r) => `<a href="?run=${esc(r.id)}">${esc(r.id)}</a>`).join(" · ");
    }
  } catch { /* first boot, no runs */ }

  const id = new URLSearchParams(location.search).get("run");
  if (id) {
    try {
      const data = await api("status", { run_id: id });
      $("#ticket").value = data.run.ticket;
      $("#url").value = data.run.url;
      setRun(data.run);
      if (data.run.status === "running") startPolling();
    } catch (e) { $("#gen-hint").textContent = e.message; }
  }
})();
