<?php declare(strict_types=1); ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>QA Bench — ticket to Playwright</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/app.css">
</head>
<body>

<header class="bench-head">
  <div class="brand">
    <span class="brand-mark">QA</span>
    <div>
      <h1>QA Bench</h1>
      <p class="tagline">Ticket &rarr; test cases &rarr; human review &rarr; Playwright, on 3 viewports</p>
    </div>
  </div>
  <div class="device-legend" aria-hidden="true">
    <span class="chip mono">desktop 1920&times;1080</span>
    <span class="chip mono">tablet 768&times;1024</span>
    <span class="chip mono">mobile 375&times;812</span>
  </div>
</header>

<main>
  <!-- 1 · Ticket input -->
  <section class="panel" id="panel-ticket">
    <div class="panel-label mono">01 · ticket</div>
    <div class="field">
      <label for="ticket">Ticket description</label>
      <textarea id="ticket" rows="8" placeholder="Paste the ticket from your internal tool. Bullet lines and should/must/verify sentences become an acceptance-criteria case."></textarea>
    </div>
    <div class="field">
      <label for="url">Target webpage URL</label>
      <input id="url" type="url" placeholder="https://staging.example.com/account" autocomplete="off">
    </div>
    <div class="actions">
      <button id="btn-generate" class="btn primary">Generate test cases</button>
      <span id="gen-hint" class="hint"></span>
    </div>
  </section>

  <!-- 2 · Review board -->
  <section class="panel hidden" id="panel-review">
    <div class="panel-label mono">02 · review</div>
    <div class="review-head">
      <h2>Generated test cases</h2>
      <p class="hint">Every case runs on all 3 viewports (locked). Approve to queue, edit to adjust — edits regenerate the Playwright script and need re-approval.</p>
    </div>
    <div id="cases"></div>
    <div class="actions run-bar">
      <button id="btn-run" class="btn primary" disabled>Run approved cases</button>
      <span id="run-hint" class="hint"></span>
    </div>
  </section>

  <!-- 3 · Results matrix -->
  <section class="panel hidden" id="panel-results">
    <div class="panel-label mono">03 · results</div>
    <div class="review-head">
      <h2>Execution matrix</h2>
      <p class="hint" id="results-hint"></p>
    </div>
    <div id="matrix"></div>
    <div class="actions">
      <a id="log-link" class="btn ghost" target="_blank" rel="noopener">Runner log</a>
    </div>
  </section>
</main>

<footer class="bench-foot mono">
  <span id="run-id-badge"></span>
  <span id="recent-runs"></span>
</footer>

<script src="assets/app.js"></script>
</body>
</html>
