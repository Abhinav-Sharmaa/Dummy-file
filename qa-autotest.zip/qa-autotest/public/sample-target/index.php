<?php declare(strict_types=1); /* Mock "page under test" for the E2E walkthrough. */ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Northbank — Account Portal (staging)</title>
<style>
  :root { --ink:#1d2733; --line:#d9dee5; --brand:#0f5a4e; }
  * { box-sizing: border-box; }
  body { margin:0; font:15px/1.55 system-ui,-apple-system,sans-serif; color:var(--ink); background:#f5f7f8; }
  header { display:flex; align-items:center; justify-content:space-between; gap:12px;
           padding:14px 20px; background:#fff; border-bottom:1px solid var(--line); }
  .logo { font-weight:700; color:var(--brand); font-size:18px; }
  nav ul { display:flex; gap:18px; list-style:none; margin:0; padding:0; }
  nav a { color:var(--ink); text-decoration:none; font-size:14px; }
  #menu-toggle { display:none; font-size:14px; padding:8px 12px; border:1px solid var(--line);
                 background:#fff; border-radius:8px; cursor:pointer; }
  main { max-width:860px; margin:0 auto; padding:24px 16px 60px; }
  h1 { font-size:24px; }
  section { background:#fff; border:1px solid var(--line); border-radius:10px; padding:20px; margin:18px 0; }
  label { display:block; font-weight:600; font-size:13px; margin:10px 0 4px; }
  input { width:100%; max-width:420px; padding:9px 11px; border:1px solid var(--line); border-radius:8px; font-size:14px; }
  button { margin-top:12px; padding:9px 16px; border:0; border-radius:8px; background:var(--brand); color:#fff;
           font-weight:600; cursor:pointer; }
  .message { display:none; margin-top:10px; font-size:14px; padding:8px 12px; border-radius:8px; }
  .message.ok { display:block; background:#e2f3e9; color:#146237; }
  .message.err { display:block; background:#fae4e2; color:#a3271f; }
  iframe { width:100%; max-width:460px; height:380px; border:1px solid var(--line); border-radius:10px; background:#fff; }
  @media (max-width:700px) {
    #menu-toggle { display:block; }
    nav { display:none; }
    nav.open { display:block; position:absolute; right:16px; top:58px; background:#fff;
               border:1px solid var(--line); border-radius:10px; padding:12px 16px; }
    nav.open ul { flex-direction:column; gap:10px; }
  }
</style>
</head>
<body>
<header>
  <span class="logo">Northbank</span>
  <button id="menu-toggle" aria-label="Open menu" aria-expanded="false">Menu</button>
  <nav id="site-nav" aria-label="Primary">
    <ul>
      <li><a href="#overview">Overview</a></li>
      <li><a href="#contact">Contact</a></li>
      <li><a href="#widget">Online banking</a></li>
    </ul>
  </nav>
</header>

<main>
  <h1 id="overview">Account portal</h1>
  <p>Staging build for ticket verification. The online banking widget below is a third-party embed.</p>

  <section id="contact" aria-labelledby="contact-h">
    <h2 id="contact-h">Request a callback</h2>
    <form id="callback-form" novalidate>
      <label for="cb-name">Full name</label>
      <input id="cb-name" name="name" type="text" required>
      <label for="cb-email">Email address</label>
      <input id="cb-email" name="email" type="email" required>
      <button type="submit">Request callback</button>
      <p class="message" id="cb-msg" role="status"></p>
    </form>
  </section>

  <section id="widget" aria-labelledby="widget-h">
    <h2 id="widget-h">Online banking</h2>
    <p>Secure sign-in is provided by our banking partner.</p>
    <iframe id="bank-widget" src="bank-widget.php" title="Northbank online banking sign-in"></iframe>
  </section>
</main>

<script>
  const toggle = document.getElementById('menu-toggle');
  const nav = document.getElementById('site-nav');
  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
  });

  const form = document.getElementById('callback-form');
  const msg = document.getElementById('cb-msg');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    if (!name || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      msg.className = 'message err';
      msg.textContent = 'Enter your full name and a valid email address.';
      return;
    }
    msg.className = 'message ok';
    msg.textContent = 'Thanks — we will call you back within one business day.';
    form.reset();
  });
</script>
</body>
</html>
