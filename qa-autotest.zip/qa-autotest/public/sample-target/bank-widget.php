<?php declare(strict_types=1); /* Mock third-party banking widget. Demo creds: qa_demo_user / S3cure!Demo */ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SecureBank widget</title>
<style>
  * { box-sizing: border-box; }
  body { margin:0; font:14px/1.5 system-ui,-apple-system,sans-serif; color:#20262e; background:#fff; padding:18px; }
  .partner { font-size:11px; letter-spacing:.12em; text-transform:uppercase; color:#6a7480; }
  h1 { font-size:17px; margin:6px 0 14px; }
  label { display:block; font-weight:600; font-size:12.5px; margin:10px 0 4px; }
  input { width:100%; padding:9px 11px; border:1px solid #ccd3da; border-radius:8px; font-size:14px; }
  button { margin-top:14px; width:100%; padding:10px; border:0; border-radius:8px;
           background:#123f8f; color:#fff; font-weight:600; cursor:pointer; }
  .status { display:none; margin-top:12px; padding:8px 11px; border-radius:8px; font-size:13.5px; }
  .status.ok { display:block; background:#e2f0e7; color:#155e33; }
  .status.err { display:block; background:#f9e3e1; color:#9e2a22; }
</style>
</head>
<body>
<span class="partner">SecureBank · partner widget</span>
<h1>Online banking sign-in</h1>
<form id="bank-login" novalidate>
  <label for="bw-user">Username</label>
  <input id="bw-user" name="username" type="text" autocomplete="off">
  <label for="bw-pass">Password</label>
  <input id="bw-pass" name="password" type="password" autocomplete="off">
  <button type="submit">Sign in</button>
  <p class="status" id="bw-status" role="alert"></p>
</form>
<script>
  const form = document.getElementById('bank-login');
  const status = document.getElementById('bw-status');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const u = form.username.value.trim();
    const p = form.password.value;
    if (!u || !p) {
      status.className = 'status err';
      status.textContent = 'Username and password are required.';
      return;
    }
    if (u === 'qa_demo_user' && p === 'S3cure!Demo') {
      status.className = 'status ok';
      status.textContent = 'Signed in — welcome back, QA Demo.';
    } else {
      status.className = 'status err';
      status.textContent = 'Invalid credentials. Try again.';
    }
  });
</script>
</body>
</html>
