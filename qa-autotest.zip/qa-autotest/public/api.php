<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/bootstrap.php';

$action = $_GET['action'] ?? '';
$body   = read_json_body();

function require_run(array $body): array
{
    $id = (string) ($body['run_id'] ?? $_GET['run_id'] ?? '');
    if (!valid_run_id($id)) {
        json_fail('Invalid run id.');
    }
    $run = Storage::load($id);
    if ($run === null) {
        json_fail('Run not found.', 404);
    }
    return $run;
}

function find_case(array &$run, string $caseId): ?array
{
    foreach ($run['cases'] as $i => $case) {
        if ($case['id'] === $caseId) {
            return ['index' => $i, 'case' => $case];
        }
    }
    return null;
}

switch ($action) {

    case 'generate': {
        $ticket = trim((string) ($body['ticket'] ?? ''));
        $url    = trim((string) ($body['url'] ?? ''));
        if ($ticket === '') {
            json_fail('Ticket description is required.');
        }
        if (!filter_var($url, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $url)) {
            json_fail('Target URL must be a valid http(s) URL.');
        }
        $run = [
            'id'      => new_run_id(),
            'created' => date('c'),
            'url'     => $url,
            'ticket'  => $ticket,
            'status'  => 'review',   // review | running | done | error
            'cases'   => TestCaseGenerator::generate($ticket, $url),
            'results' => new stdClass(),
        ];
        Storage::save($run);
        json_out(['ok' => true, 'run' => $run]);
    }

    case 'get': {
        json_out(['ok' => true, 'run' => require_run($body)]);
    }

    case 'set_status': {
        // Approve / reject a single case.
        $run = require_run($body);
        if ($run['status'] === 'running') {
            json_fail('Run is executing; cases are locked.');
        }
        $status = (string) ($body['status'] ?? '');
        if (!in_array($status, ['approved', 'rejected', 'pending'], true)) {
            json_fail('Status must be approved, rejected or pending.');
        }
        $hit = find_case($run, (string) ($body['case_id'] ?? ''));
        if ($hit === null) {
            json_fail('Case not found.', 404);
        }
        $run['cases'][$hit['index']]['status'] = $status;
        Storage::save($run);
        json_out(['ok' => true, 'run' => $run]);
    }

    case 'save_case': {
        // Edit a case. Devices stay locked to the mandatory 3-viewport matrix.
        // Any edit drops the case back to "pending": it must be re-approved, and
        // its Playwright script is regenerated from the new JSON at execution time.
        $run = require_run($body);
        if ($run['status'] === 'running') {
            json_fail('Run is executing; cases are locked.');
        }
        $hit = find_case($run, (string) ($body['case_id'] ?? ''));
        if ($hit === null) {
            json_fail('Case not found.', 404);
        }
        $clean = static fn (array $lines): array => array_values(array_filter(
            array_map(trim(...), $lines),
            static fn (string $l): bool => $l !== ''
        ));
        $case = $hit['case'];
        $case['title']         = trim((string) ($body['title'] ?? $case['title'])) ?: $case['title'];
        $case['preconditions'] = $clean((array) ($body['preconditions'] ?? $case['preconditions']));
        $case['steps']         = $clean((array) ($body['steps'] ?? $case['steps']));
        $case['expected']      = trim((string) ($body['expected'] ?? $case['expected']));
        $case['status']        = 'pending';
        $case['edited']        = true;
        if ($case['steps'] === []) {
            json_fail('A case needs at least one step.');
        }
        $run['cases'][$hit['index']] = $case;
        Storage::save($run);
        json_out(['ok' => true, 'run' => $run]);
    }

    case 'execute': {
        $run = require_run($body);
        if ($run['status'] === 'running') {
            json_fail('Run is already executing.');
        }
        $approved = array_filter($run['cases'], static fn (array $c): bool => $c['status'] === 'approved');
        if ($approved === []) {
            json_fail('Nothing approved. Approve at least one case first.');
        }
        $run['status']  = 'running';
        $run['results'] = new stdClass();
        $run['started'] = date('c');
        Storage::save($run);
        Runner::launch($run['id']);
        json_out(['ok' => true, 'run' => $run]);
    }

    case 'status': {
        $run = require_run($body);
        json_out([
            'ok'       => true,
            'run'      => $run,
            'progress' => Storage::progress($run['id']),
        ]);
    }

    case 'log': {
        $run = require_run($body);
        header('Content-Type: text/plain; charset=utf-8');
        echo Runner::log($run['id']);
        exit;
    }

    case 'runs': {
        json_out(['ok' => true, 'runs' => Storage::recent()]);
    }

    default:
        json_fail('Unknown action.', 404);
}
