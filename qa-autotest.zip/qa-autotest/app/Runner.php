<?php
declare(strict_types=1);

/**
 * shell_exec bridge. The run id is the ONLY value interpolated into the command
 * line, and it is both format-validated (valid_run_id) and shell-escaped.
 * Ticket text and URL never touch the shell — the runner reads them from the
 * run's JSON file on disk.
 */
final class Runner
{
    public static function launch(string $runId): void
    {
        $log = RUNS_DIR . '/' . $runId . '.runner.log';
        $cmd = sprintf(
            'cd %s && nohup %s run.js --run %s > %s 2>&1 & echo $!',
            escapeshellarg(RUNNER_DIR),
            escapeshellarg(NODE_BIN),
            escapeshellarg($runId),
            escapeshellarg($log)
        );
        shell_exec($cmd);
    }

    public static function log(string $runId): string
    {
        $path = RUNS_DIR . '/' . $runId . '.runner.log';
        return is_file($path) ? (string) file_get_contents($path) : '';
    }
}
