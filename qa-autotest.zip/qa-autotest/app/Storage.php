<?php
declare(strict_types=1);

final class Storage
{
    private static function pathFor(string $runId): string
    {
        return RUNS_DIR . '/' . $runId . '.json';
    }

    public static function load(string $runId): ?array
    {
        $path = self::pathFor($runId);
        if (!is_file($path)) {
            return null;
        }
        $data = json_decode((string) file_get_contents($path), true);
        return is_array($data) ? $data : null;
    }

    /** Atomic write: tmp file + rename, so the Node runner never reads a half-written file. */
    public static function save(array $run): void
    {
        $path = self::pathFor($run['id']);
        $tmp  = $path . '.tmp';
        file_put_contents($tmp, json_encode($run, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
        rename($tmp, $path);
    }

    /** Runner progress heartbeat, written by run.js while executing. */
    public static function progress(string $runId): ?array
    {
        $path = RUNS_DIR . '/' . $runId . '.status.json';
        if (!is_file($path)) {
            return null;
        }
        $data = json_decode((string) file_get_contents($path), true);
        return is_array($data) ? $data : null;
    }

    /** @return array<int, array{id:string, url:string, created:string, status:string}> */
    public static function recent(int $limit = 8): array
    {
        $files = glob(RUNS_DIR . '/*.json') ?: [];
        rsort($files);
        $out = [];
        foreach (array_slice($files, 0, $limit) as $file) {
            $run = json_decode((string) file_get_contents($file), true);
            if (!is_array($run) || !isset($run['id'])) {
                continue;
            }
            $out[] = [
                'id'      => $run['id'],
                'url'     => $run['url'] ?? '',
                'created' => $run['created'] ?? '',
                'status'  => $run['status'] ?? 'draft',
            ];
        }
        return $out;
    }
}
